package br.apsu.core;

import br.apsu.audio.AudioManager;
import br.apsu.model.boss.BossEntity;
import br.apsu.model.enemy.EnemyEntity;
import br.apsu.model.enemy.EnemyType;
import br.apsu.model.environment.Difficulty;
import br.apsu.model.environment.Projectile;
import br.apsu.model.environment.SceneryElement;
import br.apsu.model.guardian.GuardianEntity;
import br.apsu.model.hero.HeroEntity;
import br.apsu.model.hero.HeroType;
import br.apsu.model.particle.ParticleSystem;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Gerenciador mestre de estado, lógica e atualização das regras do jogo.
 * Sprint 5: 5 fases, Bug B3 corrigido (coordenadas de mundo consistentes),
 * mecânicas ambientais (correntes, pressão, obstáculos móveis, lava).
 */
public class GameContext {
    /** NOTA IMPORTANTE — SISTEMA DE COORDENADAS:
     * Herói, inimigos e projéteis operam em COORDENADAS DE MUNDO (worldX).
     * A câmera converte para tela APENAS na hora de renderizar.
     * Toda colisão lógica usa coordenadas de MUNDO. */
    public enum State { MENU, DIALOGUE, P1, P2, P3, P4, P5, WIN, OVER }

    private State state = State.MENU;
    private Difficulty difficulty = Difficulty.MEDIO;
    private HeroType heroType = HeroType.GUARDIAO;
    private HeroEntity hero;
    private BossEntity boss;

    private int currentPhase = 0;
    private int phaseDone = 0;
    private int tabletsCollected = 0;
    private boolean backtrackingActive = false;
    private static final int TOTAL_TABLETS = 5;

    private final List<EnemyEntity> enemies = new ArrayList<>();
    private final List<Projectile> projectiles = new ArrayList<>();
    private final List<GuardianEntity> guardians = new ArrayList<>();
    private final List<SceneryElement> sceneryElements = new ArrayList<>();
    private final ParticleSystem particleSystem = new ParticleSystem();

    private final InputManager inputManager = new InputManager();
    private final Camera camera = new Camera(1366, 4000);

    // Baú (Fase 2)
    private double chestWX = 1600, chestWY = 768 - 170;
    private boolean chestOpen = false;
    private long chestTime = 0;

    // Menu & Diálogos
    private int menuSel = 2; // 0=Difficulty, 1=Hero, 2=Start Game
    private int dlgPhase = 0;
    private int dlgIdx = 0;

    // Overlay de diálogo
    private boolean overlayActive = false;
    private int overlayIdx = 0;
    private String overlayName;
    private String[] overlayLines;
    private long overlayCharTime;
    private int overlayCharsShown;
    private Runnable overlayOnComplete;
    private int overlayGuardianType = 0;

    private String alertMessage = "";
    private long alertTime = 0;
    private long phaseStartTime = 0;
    private int phaseHits = 0;
    private long nanoTime = 0;

    // Mecânicas ambientais ativas
    private boolean inCurrent = false;
    private double currentFx = 0, currentFy = 0;
    private boolean inPressureZone = false;
    private double pressureBuoyMult = 1.0;

    public GameContext() {
        this.hero = new HeroEntity(heroType, difficulty.getInitialHP());
    }

    public void cycleDiff(int dir) {
        Difficulty[] vals = Difficulty.values();
        difficulty = vals[(difficulty.ordinal() + dir + vals.length) % vals.length];
        hero.setMaxHP(difficulty.getInitialHP());
    }

    public void cycleHero(int dir) {
        HeroType[] vals = HeroType.values();
        heroType = vals[(heroType.ordinal() + dir + vals.length) % vals.length];
        hero.setType(heroType);
    }

    public void onKey(KeyCode k) {
        if (overlayActive) {
            if (k == KeyCode.ESCAPE) {
                overlayActive = false;
                if (overlayOnComplete != null) overlayOnComplete.run();
                return;
            }
            if (k == KeyCode.SPACE || k == KeyCode.ENTER || k == KeyCode.E || k == KeyCode.F) {
                advanceOverlay();
            }
            return;
        }

        switch (state) {
            case MENU -> menuKey(k);
            case DIALOGUE -> {
                if (k == KeyCode.ESCAPE) {
                    advancePhaseFromDialogue();
                    return;
                }
                if (k == KeyCode.SPACE || k == KeyCode.ENTER || k == KeyCode.E || k == KeyCode.F) {
                    String[] currentDlg = GuardianEntity.DIALOGUES[Math.min(dlgPhase, GuardianEntity.DIALOGUES.length - 1)];
                    if (++dlgIdx >= currentDlg.length) {
                        advancePhaseFromDialogue();
                    }
                    AudioManager.getInstance().playSound("collect");
                }
            }
            case P1, P2, P3, P4, P5 -> {
                if (k == KeyCode.ESCAPE) state = State.MENU;
            }
            case WIN, OVER -> {
                if (k == KeyCode.SPACE || k == KeyCode.ENTER || k == KeyCode.R) {
                    state = State.MENU;
                }
            }
        }
    }

    /** Avança para a fase correta após o diálogo. */
    private void advancePhaseFromDialogue() {
        switch (dlgPhase) {
            case 0 -> startP1();
            case 1 -> startP2();
            case 2 -> startP3();
            case 3 -> startP4();
            case 4 -> startP5();
        }
    }

    private void menuKey(KeyCode k) {
        if (k == KeyCode.UP   || k == KeyCode.W) menuSel = (menuSel - 1 + 3) % 3;
        if (k == KeyCode.DOWN || k == KeyCode.S) menuSel = (menuSel + 1) % 3;
        if (k == KeyCode.LEFT || k == KeyCode.A) {
            if (menuSel == 0) cycleDiff(-1);
            else if (menuSel == 1) cycleHero(-1);
        }
        if (k == KeyCode.RIGHT|| k == KeyCode.D) {
            if (menuSel == 0) cycleDiff(+1);
            else if (menuSel == 1) cycleHero(+1);
        }
        if (k == KeyCode.ENTER || k == KeyCode.SPACE || k == KeyCode.E) {
            switch (menuSel) {
                case 0 -> cycleDiff(+1);
                case 1 -> cycleHero(+1);
                case 2 -> { reset(); transitionToPhase(1); }
            }
            AudioManager.getInstance().playSound("collect");
        }
    }

    public void reset() {
        hero.setMaxHP(difficulty.getInitialHP());
        hero.resetPosition(100, 768 / 2.0 - HeroEntity.HH / 2.0);
        tabletsCollected = 0;
        camera.setX(0);
        backtrackingActive = false;
        chestOpen = false;
        enemies.clear();
        projectiles.clear();
        guardians.clear();
        sceneryElements.clear();
        particleSystem.clear();
        alertMessage = "";
        phaseHits = 0;
        overlayActive = false;
        currentPhase = 0;
        inCurrent = false;
        inPressureZone = false;
    }

    public void transitionToPhase(int targetPhase) {
        dlgPhase = targetPhase - 1;
        dlgIdx = 0;
        state = State.DIALOGUE;
    }

    // =========================================================
    // FASE 1 — Águas Claras (introdução, enguia corrigida)
    // =========================================================
    public void startP1() {
        enemies.clear(); projectiles.clear(); guardians.clear(); sceneryElements.clear();
        camera.setX(0); hero.setX(100); hero.setY(768 / 2.0);
        double spd = difficulty.getEnemySpeedMult();
        double gX = (difficulty == Difficulty.DIFICIL) ? 400 : 900;
        guardians.add(new GuardianEntity(0, gX, 768 - GuardianEntity.GH - 60));

        enemies.add(new EnemyEntity(EnemyType.PEIXE,     1200, 768 * .44, spd,       65));
        enemies.add(new EnemyEntity(EnemyType.ENGUIA,    1900, 768 * .30, spd * 1.3, 80));  // B2-FIX: escala corrigida no enum
        enemies.add(new EnemyEntity(EnemyType.MEDUSA,    2700, 768 * .55, spd,       70));
        enemies.add(new EnemyEntity(EnemyType.PEIXE,     3200, 768 * .35, spd * 1.1, 55));
        enemies.add(new EnemyEntity(EnemyType.CARANGUEJO,3500, 768 * .50, spd,       60));

        // Gêiser na Fase 1 como tutorial de mecânica ambiental
        sceneryElements.add(new SceneryElement(SceneryElement.Type.GEYSER, 2400, 768 - 200, 70, 200));

        currentPhase = 1;
        state = State.P1; phaseStartTime = nanoTime; phaseHits = 0;
        if (difficulty == Difficulty.DIFICIL) {
            showAlert("⚓ Fase 1 (DIFÍCIL) — O portal final estará selado até você resgatar a Tabuleta!");
        } else {
            showAlert("⚓ Fase 1 — Águas Claras | Encontre o Guardião Atlante e colete a Tabuleta!");
        }
    }

    // =========================================================
    // FASE 2 — Cavernas de Coral (bolhas desbloqueadas aqui)
    // =========================================================
    public void startP2() {
        enemies.clear(); projectiles.clear(); guardians.clear(); sceneryElements.clear();
        camera.setX(0); hero.setX(100); hero.setY(768 / 2.0);
        double spd = difficulty.getEnemySpeedMult();

        enemies.add(new EnemyEntity(EnemyType.CARANGUEJO, 900,  768 * .52, spd,       35));
        enemies.add(new EnemyEntity(EnemyType.MEDUSA,     1700, 768 * .38, spd,       90));
        enemies.add(new EnemyEntity(EnemyType.CARANGUEJO, 2600, 768 * .48, spd,       45));
        enemies.add(new EnemyEntity(EnemyType.ENGUIA,     3200, 768 * .33, spd * 1.2, 75));

        double gX = (difficulty == Difficulty.DIFICIL) ? 600 : 1300;
        guardians.add(new GuardianEntity(1, gX, 768 - GuardianEntity.GH - 60));

        // Gêiseres — agora com impulso vertical real (tratado em updateP2)
        sceneryElements.add(new SceneryElement(SceneryElement.Type.GEYSER, 2100, 768 - 200, 70, 200));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.GEYSER, 2900, 768 - 200, 70, 200));

        // Labirinto de coral
        double[] cxArr = {500, 820, 1140, 1460, 1780, 2100, 2430, 2750, 3080};
        double[] gapY  = {160, 420,  230,  460,  190,  380,  270,  440,  200};
        final double gapH = 260;
        for (int i = 0; i < cxArr.length; i++) {
            double topH = gapY[i];
            double botY = topH + gapH;
            double botH = 768 - botY;
            if (topH > 20) sceneryElements.add(new SceneryElement(SceneryElement.Type.CORAL, cxArr[i], 0, 90, topH));
            if (botH > 20) sceneryElements.add(new SceneryElement(SceneryElement.Type.CORAL, cxArr[i], botY, 90, botH));
        }

        chestWX = 1600; chestWY = 768 - 170;
        currentPhase = 2;
        state = State.P2; phaseStartTime = nanoTime; phaseHits = 0;
        showAlert("🪸 Fase 2 — Cavernas de Coral | Desperte o Poder das Bolhas no Galeão Naufragado!");
    }

    // =========================================================
    // FASE 3 — Correntes Abissais (nova mecânica principal)
    // =========================================================
    public void startP3() {
        enemies.clear(); projectiles.clear(); guardians.clear(); sceneryElements.clear();
        camera.setX(0); hero.setX(100); hero.setY(768 / 2.0);
        double spd = difficulty.getEnemySpeedMult();

        enemies.add(new EnemyEntity(EnemyType.PEIXE,     800,  768 * .40, spd * 1.2, 55));
        enemies.add(new EnemyEntity(EnemyType.ENGUIA,    1400, 768 * .30, spd * 1.4, 80));
        enemies.add(new EnemyEntity(EnemyType.CARANGUEJO,2000, 768 * .50, spd,       70));
        enemies.add(new EnemyEntity(EnemyType.MEDUSA,    2500, 768 * .25, spd * 1.1, 90));
        enemies.add(new EnemyEntity(EnemyType.ENGUIA,    3000, 768 * .45, spd * 1.5, 80));
        enemies.add(new EnemyEntity(EnemyType.PEIXE,     3500, 768 * .35, spd * 1.3, 55));

        double gX = (difficulty == Difficulty.DIFICIL) ? 600 : 1100;
        guardians.add(new GuardianEntity(2, gX, 768 - GuardianEntity.GH - 60));

        // Correntes de água — mecânica principal da Fase 3
        sceneryElements.add(new SceneryElement(SceneryElement.Type.CURRENT, 1200, 100, 220, 600).withCurrent(-4.5, 0));   // corrente para esquerda
        sceneryElements.add(new SceneryElement(SceneryElement.Type.CURRENT, 2200, 200, 220, 500).withCurrent(0, 3.5));    // corrente para baixo
        sceneryElements.add(new SceneryElement(SceneryElement.Type.CURRENT, 3000, 50, 220, 650).withCurrent(5.0, -1.5));  // corrente diagonal

        // Zonas de empuxo variável
        sceneryElements.add(new SceneryElement(SceneryElement.Type.PRESSURE_ZONE, 1700, 0, 200, 768).withBuoyancy(2.8));  // sobe forte
        sceneryElements.add(new SceneryElement(SceneryElement.Type.PRESSURE_ZONE, 2700, 0, 200, 768).withBuoyancy(0.1)); // afunda

        // Obstáculos móveis — pedras oscilando
        sceneryElements.add(new SceneryElement(SceneryElement.Type.MOVING_OBSTACLE, 900, 300, 100, 80).withOscillation(0, 160, 1.2, 0.0));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.MOVING_OBSTACLE, 1550, 200, 100, 80).withOscillation(120, 0, 0.8, 1.0));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.MOVING_OBSTACLE, 2450, 400, 100, 80).withOscillation(0, 200, 1.5, 2.0));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.MOVING_OBSTACLE, 3200, 150, 110, 80).withOscillation(80, 120, 1.0, 0.5));

        // Gêiseres mais intensos na Fase 3
        sceneryElements.add(new SceneryElement(SceneryElement.Type.GEYSER, 1600, 768 - 200, 80, 200));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.GEYSER, 3400, 768 - 200, 80, 200));

        currentPhase = 3;
        state = State.P3; phaseStartTime = nanoTime; phaseHits = 0;
        showAlert("🌊 Fase 3 — Correntes Abissais | As águas vivem — lute contra a maré!");
    }

    // =========================================================
    // FASE 4 — Abismo Vulcânico (novos inimigos + lava)
    // =========================================================
    public void startP4() {
        enemies.clear(); projectiles.clear(); guardians.clear(); sceneryElements.clear();
        camera.setX(0); hero.setX(100); hero.setY(768 / 2.0);
        double spd = difficulty.getEnemySpeedMult();

        enemies.add(new EnemyEntity(EnemyType.ARRAIAO,   700,  768 * .45, spd,       90));
        enemies.add(new EnemyEntity(EnemyType.PEIXE,     1100, 768 * .30, spd * 1.4, 55));
        enemies.add(new EnemyEntity(EnemyType.ARRAIAO,   1600, 768 * .55, spd * 1.1, 90));
        enemies.add(new EnemyEntity(EnemyType.MEDUSA,    2100, 768 * .35, spd * 1.2, 90));
        enemies.add(new EnemyEntity(EnemyType.LEVIATA,   2600, 768 * .40, spd * 1.3, 130));
        enemies.add(new EnemyEntity(EnemyType.ARRAIAO,   3200, 768 * .50, spd * 1.5, 90));
        enemies.add(new EnemyEntity(EnemyType.CARANGUEJO,3600, 768 * .35, spd * 1.2, 70));

        double gX = (difficulty == Difficulty.DIFICIL) ? 500 : 1000;
        guardians.add(new GuardianEntity(3, gX, 768 - GuardianEntity.GH - 60));

        // Zonas de lava — dano contínuo
        sceneryElements.add(new SceneryElement(SceneryElement.Type.LAVA_POOL, 1400, 768 - 90, 300, 90));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.LAVA_POOL, 2300, 768 - 90, 250, 90));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.LAVA_POOL, 3300, 768 - 90, 350, 90));

        // Rochas vulcânicas estáticas — colisão com dano
        sceneryElements.add(new SceneryElement(SceneryElement.Type.VOLCANIC_ROCK, 900,  0,    80, 280));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.VOLCANIC_ROCK, 1900, 768 - 300, 80, 300));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.VOLCANIC_ROCK, 2700, 0,    80, 220));

        // Obstáculos móveis de rocha incandescente
        sceneryElements.add(new SceneryElement(SceneryElement.Type.MOVING_OBSTACLE, 1250, 250, 90, 90).withOscillation(0, 200, 1.8, 0.0));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.MOVING_OBSTACLE, 2050, 150, 90, 90).withOscillation(150, 100, 1.3, 1.5));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.MOVING_OBSTACLE, 3000, 300, 90, 90).withOscillation(0, 250, 2.0, 0.8));

        // Correntes de calor ascendentes perto dos vulcões
        sceneryElements.add(new SceneryElement(SceneryElement.Type.CURRENT, 1400, 200, 120, 400).withCurrent(0, -5.5));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.CURRENT, 2300, 200, 120, 400).withCurrent(0, -6.0));

        // Gêiseres de lava — super intensos
        sceneryElements.add(new SceneryElement(SceneryElement.Type.GEYSER, 1700, 768 - 200, 80, 200));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.GEYSER, 2900, 768 - 200, 80, 200));

        currentPhase = 4;
        state = State.P4; phaseStartTime = nanoTime; phaseHits = 0;
        showAlert("🌋 Fase 4 — Abismo Vulcânico | A lava devora tudo — mantenha altitude!");
    }

    // =========================================================
    // FASE 5 — Templo Final de Apsu (boss + guardião Enki)
    // =========================================================
    public void startP5() {
        enemies.clear(); projectiles.clear(); guardians.clear(); sceneryElements.clear();
        // Fase 5 é a arena do boss — herói entra pela esquerda, boss à direita
        // BUGFIX 2026-08-15 (causa-raiz, complementar ao fix em updateP5()):
        // P5 nunca chama camera.update() — é arena fixa, hero/boss.getX() são
        // usados diretamente como coordenada de TELA. Sem este reset, a câmera
        // mantinha o offset acumulado da Fase 4 (até ~2634px), o que já causava
        // o burst de partícula fora da tela e poderia afetar qualquer outro
        // código futuro que assuma camera.getX()==0 durante a arena do boss.
        camera.setX(0);
        guardians.add(new GuardianEntity(4, 160, 768 / 2.0 - GuardianEntity.GH)); // Enki em pessoa!

        int bossVar = (difficulty == Difficulty.DIFICIL) ? (1 + (int)(Math.random() * 2)) : 0;
        boss = new BossEntity(bossVar, 1366 - BossEntity.BW - 80, 768 / 2.0 - BossEntity.BH / 2);

        hero.setX(80); hero.setY(768 / 2.0 - HeroEntity.HH / 2);

        // Correntes na arena do boss — obrigam o jogador a dominar a mecânica
        sceneryElements.add(new SceneryElement(SceneryElement.Type.CURRENT, 400, 200, 150, 400).withCurrent(0, -3.5));
        sceneryElements.add(new SceneryElement(SceneryElement.Type.CURRENT, 800, 100, 150, 500).withCurrent(0, 4.0));

        // Zonas de pressão que mudam a dinâmica da arena
        sceneryElements.add(new SceneryElement(SceneryElement.Type.PRESSURE_ZONE, 550, 0, 120, 768).withBuoyancy(0.2));

        currentPhase = 5;
        state = State.P5; phaseStartTime = nanoTime; phaseHits = 0;
        showAlert("💀 Fase 5 — Templo de Apsu | Derrote " + boss.getName() + "! Use tudo que aprendeu!");
    }

    // =========================================================
    // UPDATE PRINCIPAL
    // =========================================================
    public void update(long currentNanoTime) {
        this.nanoTime = currentNanoTime;
        double timeSeconds = nanoTime / 1_000_000_000.0;

        if (overlayActive && overlayLines != null && overlayIdx < overlayLines.length) {
            long elapsed = nanoTime - overlayCharTime;
            overlayCharsShown = Math.min(
                overlayLines[overlayIdx].length(),
                (int)(elapsed / 18_000_000L)
            );
        }

        hero.checkInvulnerability(nanoTime);
        particleSystem.update();

        // Atualiza obstáculos móveis
        for (SceneryElement elem : sceneryElements) {
            elem.updatePosition(timeSeconds);
        }

        switch (state) {
            case P1 -> updateP1();
            case P2 -> updateP2();
            case P3 -> updateP3();
            case P4 -> updateP4();
            case P5 -> updateP5();
        }
    }

    // =========================================================
    // UPDATE P1
    // =========================================================
    private void updateP1() {
        applyEnvironmentalForces();
        hero.updatePhysics(
            inputManager.isPressed(KeyCode.LEFT, KeyCode.A),
            inputManager.isPressed(KeyCode.RIGHT, KeyCode.D),
            inputManager.isPressed(KeyCode.UP, KeyCode.W),
            inputManager.isPressed(KeyCode.DOWN, KeyCode.S),
            30, 768 - HeroEntity.HH - 30, phaseDone,
            inPressureZone ? pressureBuoyMult : 1.0,
            inCurrent ? currentFx : 0, inCurrent ? currentFy : 0
        );

        if (!overlayActive && inputManager.isPressed(KeyCode.SPACE)) tryShoot();
        camera.update(hero.getX());
        hero.setX(Math.max(30, Math.min(4000 - HeroEntity.HW - 30, hero.getX())));

        checkGuardians(false);
        checkSceneryCollisions();
        updateProjectiles();
        updateEnemies();
        checkEnemyCollisions();

        if (hero.getX() > 4000 - 200) {
            if (tabletsCollected >= 1) {
                phaseDone = Math.max(phaseDone, 1);
                transitionToPhase(2);
            } else if (difficulty == Difficulty.DIFICIL && !backtrackingActive) {
                backtrackingActive = true;
                enemies.add(new EnemyEntity(EnemyType.PEIXE,  1500, 768 * .40, 1.8, 50));
                enemies.add(new EnemyEntity(EnemyType.MEDUSA, 2200, 768 * .60, 2.0, 70));
                showAlert("🔒 Barreira Rúnica Selada! Retroceda para encontrar o Guardião escondido!");
            }
        }
    }

    // =========================================================
    // UPDATE P2 — B3-FIX: bolhas agora funcionam corretamente
    // =========================================================
    private void updateP2() {
        applyEnvironmentalForces();
        hero.updatePhysics(
            inputManager.isPressed(KeyCode.LEFT, KeyCode.A),
            inputManager.isPressed(KeyCode.RIGHT, KeyCode.D),
            inputManager.isPressed(KeyCode.UP, KeyCode.W),
            inputManager.isPressed(KeyCode.DOWN, KeyCode.S),
            60, 768 - HeroEntity.HH - 60, phaseDone,
            inPressureZone ? pressureBuoyMult : 1.0,
            inCurrent ? currentFx : 0, inCurrent ? currentFy : 0
        );

        if (!overlayActive && inputManager.isPressed(KeyCode.SPACE)) tryShoot();
        camera.update(hero.getX());
        hero.setX(Math.max(30, Math.min(4000 - HeroEntity.HW - 30, hero.getX())));

        // Colisões com coral (coordenadas de mundo)
        for (SceneryElement elem : sceneryElements) {
            if (elem.getType() == SceneryElement.Type.CORAL) {
                if (rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                             elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                    // Empurra herói para fora do coral
                    hero.setY((elem.getWorldY() == 0)
                        ? elem.getWorldY() + elem.getHeight() + 2
                        : elem.getWorldY() - HeroEntity.HH - 2);
                    hero.applyDamage(difficulty.getCollisionDamage(), nanoTime);
                    particleSystem.addBurst(camera.toScreenX(hero.getX()) + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.ORANGERED);
                    AudioManager.getInstance().playSound("hurt");
                }
            }
        }

        // Gêiseres com impulso vertical real (B3-adjacente: mesmo sistema)
        for (SceneryElement elem : sceneryElements) {
            if (elem.getType() == SceneryElement.Type.GEYSER) {
                if (rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                             elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                    hero.applyGeyserImpulse(-12.0); // impulso vertical para cima
                    hero.applyDamage(difficulty.getCollisionDamage() * 0.5, nanoTime);
                    particleSystem.addBurst(camera.toScreenX(hero.getX()) + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.GOLDENROD);
                    AudioManager.getInstance().playSound("hurt");
                }
            }
        }

        checkGuardians(false);

        // Baú (B3-FIX: coordenadas de mundo para colisão com baú)
        if (!chestOpen && inputManager.isInteractPressed()
                && rectsHit(hero.getX(), hero.getY(), HeroEntity.HW + 80, HeroEntity.HH + 80,
                            chestWX - 40, chestWY - 40, 160, 140)) {
            chestOpen = true; chestTime = nanoTime;
            hero.setHasBubblePower(true);
            double csx = camera.toScreenX(chestWX);
            particleSystem.addBurst(csx + 60, chestWY + 40, Color.GOLD);
            particleSystem.addBurst(csx + 60, chestWY + 40, Color.CYAN);
            AudioManager.getInstance().playSound("collect");
            AudioManager.getInstance().playSound("victory");
            showAlert("✦ PODER DAS BOLHAS DESPERTADO! Pressione ESPAÇO para disparar! ✦");
        }

        updateProjectiles();
        updateEnemies();
        checkEnemyCollisions();

        if (hero.getX() > 4000 - 200) {
            if (tabletsCollected >= 2) {
                phaseDone = Math.max(phaseDone, 2);
                transitionToPhase(3);
            } else if (difficulty == Difficulty.DIFICIL && !backtrackingActive) {
                backtrackingActive = true;
                enemies.add(new EnemyEntity(EnemyType.ENGUIA,    1400, 768 * .50, 2.0, 60));
                enemies.add(new EnemyEntity(EnemyType.CARANGUEJO, 2500, 768 * .35, 2.2, 80));
                showAlert("🔒 Barreira Rúnica Selada! Retroceda para encontrar o Guardião nas cavernas!");
            }
        }
    }

    // =========================================================
    // UPDATE P3 — Correntes Abissais
    // =========================================================
    private void updateP3() {
        applyEnvironmentalForces();
        hero.updatePhysics(
            inputManager.isPressed(KeyCode.LEFT, KeyCode.A),
            inputManager.isPressed(KeyCode.RIGHT, KeyCode.D),
            inputManager.isPressed(KeyCode.UP, KeyCode.W),
            inputManager.isPressed(KeyCode.DOWN, KeyCode.S),
            20, 768 - HeroEntity.HH - 20, phaseDone,
            inPressureZone ? pressureBuoyMult : 1.0,
            inCurrent ? currentFx : 0, inCurrent ? currentFy : 0
        );

        if (!overlayActive && inputManager.isPressed(KeyCode.SPACE)) tryShoot();
        camera.update(hero.getX());
        hero.setX(Math.max(30, Math.min(4000 - HeroEntity.HW - 30, hero.getX())));

        checkGuardians(false);
        checkSceneryCollisions();
        updateProjectiles();
        updateEnemies();
        checkEnemyCollisions();

        if (hero.getX() > 4000 - 200) {
            if (tabletsCollected >= 3) {
                phaseDone = Math.max(phaseDone, 3);
                transitionToPhase(4);
            } else if (difficulty == Difficulty.DIFICIL && !backtrackingActive) {
                backtrackingActive = true;
                enemies.add(new EnemyEntity(EnemyType.ENGUIA, 2000, 768 * .40, 2.2, 80));
                showAlert("🔒 Barreira das Correntes! Encontre o Lamassu Aquático antes de avançar!");
            }
        }
    }

    // =========================================================
    // UPDATE P4 — Abismo Vulcânico
    // =========================================================
    private void updateP4() {
        applyEnvironmentalForces();
        hero.updatePhysics(
            inputManager.isPressed(KeyCode.LEFT, KeyCode.A),
            inputManager.isPressed(KeyCode.RIGHT, KeyCode.D),
            inputManager.isPressed(KeyCode.UP, KeyCode.W),
            inputManager.isPressed(KeyCode.DOWN, KeyCode.S),
            20, 768 - HeroEntity.HH - 20, phaseDone,
            inPressureZone ? pressureBuoyMult : 1.0,
            inCurrent ? currentFx : 0, inCurrent ? currentFy : 0
        );

        if (!overlayActive && inputManager.isPressed(KeyCode.SPACE)) tryShoot();
        camera.update(hero.getX());
        hero.setX(Math.max(30, Math.min(4000 - HeroEntity.HW - 30, hero.getX())));

        // Dano contínuo em zonas de lava (leve por segundo)
        long currentSec = nanoTime / 1_000_000_000L;
        for (SceneryElement elem : sceneryElements) {
            if (elem.getType() == SceneryElement.Type.LAVA_POOL && !hero.isInvulnerable()) {
                if (rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                             elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                    hero.applyDamage(difficulty.getCollisionDamage() * 0.8, nanoTime);
                    particleSystem.addBurst(camera.toScreenX(hero.getX()) + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.ORANGERED);
                    AudioManager.getInstance().playSound("hurt");
                    break;
                }
            }
        }

        checkGuardians(false);
        checkSceneryCollisions();
        updateProjectiles();
        updateEnemies();
        checkEnemyCollisions();

        if (hero.getX() > 4000 - 200) {
            if (tabletsCollected >= 4) {
                phaseDone = Math.max(phaseDone, 4);
                transitionToPhase(5);
            } else if (difficulty == Difficulty.DIFICIL && !backtrackingActive) {
                backtrackingActive = true;
                enemies.add(new EnemyEntity(EnemyType.ARRAIAO, 1800, 768 * .45, 2.5, 90));
                showAlert("🔒 Selado pelas chamas! Encontre o Oráculo das Correntes primeiro!");
            }
        }
    }

    // =========================================================
    // UPDATE P5 — Templo Final (boss fight)
    // =========================================================
    private void updateP5() {
        applyEnvironmentalForces();
        hero.updatePhysics(
            inputManager.isPressed(KeyCode.LEFT, KeyCode.A),
            inputManager.isPressed(KeyCode.RIGHT, KeyCode.D),
            inputManager.isPressed(KeyCode.UP, KeyCode.W),
            inputManager.isPressed(KeyCode.DOWN, KeyCode.S),
            20, 768 - HeroEntity.HH - 20, phaseDone,
            inPressureZone ? pressureBuoyMult : 1.0,
            inCurrent ? currentFx : 0, inCurrent ? currentFy : 0
        );
        hero.setX(Math.max(20, Math.min(1366 - HeroEntity.HW - 20, hero.getX())));

        checkGuardians(true); // arena sem câmera

        if (!overlayActive && inputManager.isPressed(KeyCode.SPACE) && nanoTime - hero.getLastShotTime() > 260_000_000L) {
            tryShoot();
        }

        if (boss != null && !boss.isDead()) {
            double t = nanoTime / 1_000_000_000.0;
            boss.updatePosition(t, 768);

            // Colisão Direta Herói <-> Boss
            if (!hero.isInvulnerable() && rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                                                     boss.getX(), boss.getY(), BossEntity.BW, BossEntity.BH)) {
                hero.applyDamage(difficulty.getCollisionDamage(), nanoTime);
                // BUGFIX 2026-08-15: P5 é arena fixa (sem scroll de câmera) — hero.getX()
                // já É a coordenada de tela nessa fase. camera.toScreenX() aqui subtraía o
                // offset residual deixado pela Fase 4 (camera.setX nunca é resetado ao
                // entrar em P5), jogando a partícula pra fora da tela.
                particleSystem.addBurst(hero.getX() + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.PURPLE);
                AudioManager.getInstance().playSound("hurt");
                if (hero.getHp() <= 0) state = State.OVER;
            }

            // Boss dispara
            long baseInterval = (difficulty == Difficulty.FACIL ? 1_800_000_000L : (difficulty == Difficulty.MEDIO ? 1_200_000_000L : 850_000_000L));
            long bullInterval = (long)(baseInterval / (getThreatMultiplier() * BossEntity.SPD_MULT[boss.getVariant()]));
            if (nanoTime - boss.getLastShotTime() > bullInterval) {
                boss.setLastShotTime(nanoTime);
                double bfx = boss.getX();
                double bfy = boss.getY() + BossEntity.BH / 2;
                int cnt = (difficulty == Difficulty.FACIL ? 3 : (difficulty == Difficulty.MEDIO ? 4 : 5));
                double tx = hero.getX() + HeroEntity.HW/2 - bfx, ty = hero.getY() + HeroEntity.HH/2 - bfy;
                double baseAngle = Math.atan2(ty, tx);
                double spread = BossEntity.SPREAD[boss.getVariant()];
                double spd = (difficulty == Difficulty.FACIL ? 4.5 : 7.0) * getThreatMultiplier() * BossEntity.SPD_MULT[boss.getVariant()];
                for (int i = 0; i < cnt; i++) {
                    double ang = baseAngle + (i - (cnt-1)/2.0) * (spread / Math.max(cnt-1, 1));
                    // Boss bullets em coordenadas de tela (arena fixa sem câmera)
                    projectiles.add(new Projectile(Projectile.Type.BOSS_BULLET, bfx, bfy, Math.cos(ang)*spd, Math.sin(ang)*spd, 0.5, true));
                }
            }
        }

        // Correntes e zonas de pressão na arena do boss — coordenadas de tela (sem scroll)
        checkSceneryCollisionsArena();
        updateProjectiles();
    }

    // =========================================================
    // MECÂNICAS AMBIENTAIS
    // =========================================================
    /** Detecta correntes e zonas de pressão ao redor do herói. */
    private void applyEnvironmentalForces() {
        inCurrent = false;
        inPressureZone = false;
        currentFx = 0; currentFy = 0;
        pressureBuoyMult = 1.0;

        for (SceneryElement elem : sceneryElements) {
            if (elem.getType() == SceneryElement.Type.CURRENT) {
                double ex = (state == State.P5) ? elem.getWorldX() : elem.getWorldX();
                if (rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                             ex, elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                    inCurrent = true;
                    currentFx = elem.getCurrentVx();
                    currentFy = elem.getCurrentVy();
                    break;
                }
            } else if (elem.getType() == SceneryElement.Type.PRESSURE_ZONE) {
                double ex = elem.getWorldX();
                if (rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                             ex, elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                    inPressureZone = true;
                    pressureBuoyMult = elem.getBuoyancyMult();
                    break;
                }
            }
        }
    }

    /** Colisões com obstáculos do cenário (mundo com câmera). */
    private void checkSceneryCollisions() {
        for (SceneryElement elem : sceneryElements) {
            switch (elem.getType()) {
                case GEYSER -> {
                    if (!hero.isInvulnerable() &&
                        rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                                 elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                        hero.applyGeyserImpulse(-14.0);
                        hero.applyDamage(difficulty.getCollisionDamage() * 0.4, nanoTime);
                        particleSystem.addBurst(camera.toScreenX(hero.getX()) + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.GOLDENROD);
                        AudioManager.getInstance().playSound("hurt");
                    }
                }
                case MOVING_OBSTACLE, VOLCANIC_ROCK -> {
                    if (!hero.isInvulnerable() &&
                        rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                                 elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                        hero.applyDamage(difficulty.getCollisionDamage(), nanoTime);
                        particleSystem.addBurst(camera.toScreenX(hero.getX()) + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.ORANGERED);
                        AudioManager.getInstance().playSound("hurt");
                        if (hero.getHp() <= 0) state = State.OVER;
                    }
                }
                case LAVA_POOL -> {
                    if (!hero.isInvulnerable() &&
                        rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                                 elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                        hero.applyDamage(difficulty.getCollisionDamage() * 0.8, nanoTime);
                        particleSystem.addBurst(camera.toScreenX(hero.getX()) + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.web("#ff4400"));
                        AudioManager.getInstance().playSound("hurt");
                        if (hero.getHp() <= 0) state = State.OVER;
                    }
                }
                default -> {} // CORAL já tratado no updateP2
            }
        }
    }

    /** Colisões na arena sem câmera (P5). */
    private void checkSceneryCollisionsArena() {
        for (SceneryElement elem : sceneryElements) {
            if (elem.getType() == SceneryElement.Type.GEYSER) {
                if (!hero.isInvulnerable() &&
                    rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                             elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight())) {
                    hero.applyGeyserImpulse(-12.0);
                    hero.applyDamage(difficulty.getCollisionDamage() * 0.4, nanoTime);
                    particleSystem.addBurst(hero.getX() + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.GOLDENROD);
                    AudioManager.getInstance().playSound("hurt");
                }
            }
        }
    }

    /** Verifica interação com guardiões. */
    private void checkGuardians(boolean arenaMode) {
        for (GuardianEntity g : guardians) {
            double gx = arenaMode ? g.getWorldX() : camera.toScreenX(g.getWorldX());
            double heroScreenX = arenaMode ? hero.getX() : camera.toScreenX(hero.getX());
            if (!g.isContacted() && inputManager.isInteractPressed()
                    && rectsHit(heroScreenX, hero.getY(), HeroEntity.HW, HeroEntity.HH,
                                gx - 30, g.getWorldY() - 30, GuardianEntity.GW + 60, GuardianEntity.GH + 60)) {
                g.setContacted(true);
                final double finalGx = gx;
                openOverlay(g.getType(), g.getName(), g.getDialogue(), () -> {
                    tabletsCollected++;
                    hero.heal(2.0);
                    particleSystem.addBurst(finalGx + GuardianEntity.GW/2, g.getWorldY() + GuardianEntity.GH/2, Color.GOLD);
                    particleSystem.addBurst(finalGx + GuardianEntity.GW/2, g.getWorldY() + GuardianEntity.GH/2, Color.LIMEGREEN);
                    AudioManager.getInstance().playSound("collect");
                    showAlert("✦ Tabuleta " + tabletsCollected + "/" + TOTAL_TABLETS + " recebida! ❤ +2 Vida restaurada! ✦");
                });
                break;
            }
        }
    }

    // =========================================================
    // INIMIGOS
    // =========================================================
    private void updateEnemies() {
        double t = nanoTime / 1_000_000_000.0;

        for (EnemyEntity e : enemies) {
            if (!e.isAlive()) continue;
            e.update(t, getThreatMultiplier());

            if (difficulty.canEnemiesShoot()) {
                double ex = camera.toScreenX(e.getWorldX());
                double heroScreenX = camera.toScreenX(hero.getX());
                if (ex > 0 && ex < 1366 && (nanoTime - e.getLastShotTime()) > 2_400_000_000L) {
                    e.setLastShotTime(nanoTime);
                    double dx = heroScreenX + HeroEntity.HW/2 - ex;
                    double dy = hero.getY() + HeroEntity.HH/2 - e.getCurrentY();
                    double len = Math.sqrt(dx*dx + dy*dy);
                    if (len > 0) {
                        // B3-FIX: projétil inimigo criado em coordenadas de MUNDO
                        projectiles.add(new Projectile(Projectile.Type.ENEMY_MALIGN,
                            e.getWorldX(), e.getCurrentY() + e.getType().getHeight()/2,
                            dx/len * 4.5, dy/len * 4.5, 0.2, false));
                    }
                }
            }
        }
    }

    // =========================================================
    // B3-FIX PRINCIPAL — Projéteis em coordenadas de MUNDO
    // =========================================================
    private void updateProjectiles() {
        boolean isArena = (state == State.P5); // P5 sem câmera scrolling

        Iterator<Projectile> it = projectiles.iterator();
        while (it.hasNext()) {
            Projectile p = it.next();
            p.update();

            // Limites do mundo
            double maxW = isArena ? 1366 + 50 : 4050;
            if (p.getX() < -50 || p.getX() > maxW || p.getY() < -50 || p.getY() > 768 + 50) {
                it.remove(); continue;
            }

            if (p.getType() == Projectile.Type.HERO_BUBBLE) {
                // B3-FIX: bolha do herói em coordenadas de MUNDO — colisão usa worldX do inimigo
                boolean hitSomething = false;
                for (EnemyEntity e : enemies) {
                    if (!e.isAlive()) continue;
                    // Colisão MUNDO vs MUNDO (corrigido!)
                    if (rectsHit(p.getX(), p.getY(), 16, 16,
                                 e.getWorldX(), e.getCurrentY(), e.getType().getWidth(), e.getType().getHeight())) {
                        e.setAlive(false);
                        double screenPx = isArena ? p.getX() : camera.toScreenX(p.getX());
                        particleSystem.addBurst(screenPx, p.getY(), Color.AQUAMARINE);
                        AudioManager.getInstance().playSound("shoot");
                        it.remove();
                        hitSomething = true;
                        break;
                    }
                }
                if (!hitSomething && boss != null) {
                    // Boss em coordenadas de tela (arena fixa P5)
                    if (rectsHit(p.getX(), p.getY(), 16, 16, boss.getX(), boss.getY(), BossEntity.BW, BossEntity.BH)) {
                        boss.takeDamage(1);
                        particleSystem.addBurst(boss.getX() + BossEntity.BW/2, boss.getY() + BossEntity.BH/2, Color.CYAN);
                        AudioManager.getInstance().playSound("boss-hit");
                        it.remove();
                        if (boss.isDead()) {
                            particleSystem.addBurst(boss.getX() + BossEntity.BW/2, boss.getY() + BossEntity.BH/2, Color.GOLD);
                            AudioManager.getInstance().playSound("victory");
                            state = State.WIN;
                        }
                    }
                }
            } else if (p.getType() == Projectile.Type.ENEMY_MALIGN) {
                // Inimigo acerta herói — coordenadas de MUNDO
                if (!hero.isInvulnerable() &&
                    rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                             p.getX() - 8, p.getY() - 8, 16, 16)) {
                    hero.applyDamage(p.getDamage(), nanoTime);
                    double screenHX = isArena ? hero.getX() : camera.toScreenX(hero.getX());
                    particleSystem.addBurst(screenHX + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.PURPLE);
                    AudioManager.getInstance().playSound("hurt");
                    it.remove();
                    if (hero.getHp() <= 0) state = State.OVER;
                }
            } else if (p.getType() == Projectile.Type.BOSS_BULLET) {
                // Boss bullet em tela (P5)
                if (!hero.isInvulnerable() &&
                    rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                             p.getX() - 8, p.getY() - 8, 16, 16)) {
                    hero.applyDamage(p.getDamage(), nanoTime);
                    particleSystem.addBurst(hero.getX() + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.PURPLE);
                    AudioManager.getInstance().playSound("hurt");
                    it.remove();
                    if (hero.getHp() <= 0) state = State.OVER;
                }
            }
        }
    }

    // =========================================================
    // COLISÃO HERÓI <-> INIMIGOS (coordenadas de mundo)
    // =========================================================
    private void checkEnemyCollisions() {
        if (hero.isInvulnerable()) return;
        for (EnemyEntity e : enemies) {
            if (!e.isAlive()) continue;
            // B3-FIX: coordenadas de mundo para colisão consistente
            if (rectsHit(hero.getX(), hero.getY(), HeroEntity.HW, HeroEntity.HH,
                         e.getWorldX(), e.getCurrentY(), e.getType().getWidth(), e.getType().getHeight())) {
                e.setAlive(false);
                hero.applyDamage(difficulty.getCollisionDamage(), nanoTime);
                double screenX = camera.toScreenX(hero.getX());
                particleSystem.addBurst(screenX + HeroEntity.HW/2, hero.getY() + HeroEntity.HH/2, Color.RED);
                AudioManager.getInstance().playSound("hurt");
                if (hero.getHp() <= 0) state = State.OVER;
                return;
            }
        }
    }

    // =========================================================
    // DISPARO — B3-FIX: posição de mundo
    // =========================================================
    private void tryShoot() {
        if (nanoTime - hero.getLastShotTime() < 260_000_000L) return;
        hero.setLastShotTime(nanoTime);
        if (hero.hasBubblePower()) {
            hero.triggerShooting(nanoTime);
            boolean right = hero.isFacingRight();
            // B3-FIX: getBubbleSpawnX() retorna coordenada de MUNDO
            double bx = hero.getBubbleSpawnX();
            double by = hero.getBubbleSpawnY();
            double vx = (right ? 1 : -1) * 16.0 * hero.getType().getPwr();
            // isArena=false para P1-P4 (mundo com scroll), true para P5
            boolean isArena = (state == State.P5);
            projectiles.add(new Projectile(Projectile.Type.HERO_BUBBLE, bx, by, vx, 0, 1.0, isArena));
            AudioManager.getInstance().playSound("shoot");
        } else {
            // BUGFIX 2026-08-15: mesmo padrão do fix em updateP5() — se o jogador
            // chegar em P5 sem ter achado o baú (poder de bolha), este alerta
            // podia nascer fora da tela por causa do offset de câmera da arena.
            boolean arenaMode = (state == State.P5);
            double screenX = arenaMode ? hero.getX() : camera.toScreenX(hero.getX());
            particleSystem.addBurst(screenX + HeroEntity.HW / 2, hero.getY() + HeroEntity.HH / 2, hero.getType().getAura());
            showAlert("💡 Encontre o Baú no Navio Naufragado (Fase 2) para obter o Poder das Bolhas!");
        }
    }

    // =========================================================
    // OVERLAY
    // =========================================================
    public void openOverlay(int guardianType, String name, String[] lines, Runnable onComplete) {
        overlayActive = true;
        overlayGuardianType = guardianType;
        overlayIdx = 0;
        overlayName = name;
        overlayLines = lines;
        overlayCharTime = nanoTime;
        overlayCharsShown = 0;
        overlayOnComplete = onComplete;
        AudioManager.getInstance().playSound("collect");
    }

    public void advanceOverlay() {
        if (overlayLines == null || overlayIdx >= overlayLines.length) {
            overlayActive = false;
            if (overlayOnComplete != null) overlayOnComplete.run();
            return;
        }

        if (overlayCharsShown < overlayLines[overlayIdx].length()) {
            overlayCharsShown = overlayLines[overlayIdx].length();
            return;
        }

        overlayIdx++;
        AudioManager.getInstance().playSound("collect");
        if (overlayIdx < overlayLines.length) {
            overlayCharsShown = 0;
            overlayCharTime = nanoTime;
        } else {
            overlayActive = false;
            if (overlayOnComplete != null) overlayOnComplete.run();
        }
    }

    public boolean rectsHit(double x1, double y1, double w1, double h1,
                             double x2, double y2, double w2, double h2) {
        return x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2;
    }

    public double getThreatMultiplier() {
        double el = (nanoTime - phaseStartTime) / 1_000_000_000.0;
        double b = (difficulty == Difficulty.DIFICIL) ? 1.25 : (difficulty == Difficulty.MEDIO ? 0.95 : 0.65);
        double m = (phaseHits == 0 && el > 20) ? 0.18 : 0;
        double r = phaseHits > 0 ? Math.min(0.25, phaseHits * .09) : 0;
        return Math.max(0.5, Math.min(1.45, b + m - r));
    }

    public void showAlert(String msg) {
        this.alertMessage = msg;
        this.alertTime = nanoTime;
    }

    // Getters
    public State getState() { return state; }
    public void setState(State state) { this.state = state; }
    public Difficulty getDifficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }
    public HeroType getHeroType() { return heroType; }
    public void setHeroType(HeroType heroType) { this.heroType = heroType; hero.setType(heroType); }
    public HeroEntity getHero() { return hero; }
    public BossEntity getBoss() { return boss; }
    public List<EnemyEntity> getEnemies() { return enemies; }
    public List<Projectile> getProjectiles() { return projectiles; }
    public List<GuardianEntity> getGuardians() { return guardians; }
    public List<SceneryElement> getSceneryElements() { return sceneryElements; }
    public ParticleSystem getParticleSystem() { return particleSystem; }
    public InputManager getInputManager() { return inputManager; }
    public Camera getCamera() { return camera; }
    public int getTabletsCollected() { return tabletsCollected; }
    public int getTotalTablets() { return TOTAL_TABLETS; }
    public boolean isOverlayActive() { return overlayActive; }
    public int getOverlayGuardianType() { return overlayGuardianType; }
    public int getOverlayIdx() { return overlayIdx; }
    public String getOverlayName() { return overlayName; }
    public String[] getOverlayLines() { return overlayLines; }
    public int getOverlayCharsShown() { return overlayCharsShown; }
    public String getAlertMessage() { return alertMessage; }
    public long getAlertTime() { return alertTime; }
    public long getNanoTime() { return nanoTime; }
    public int getDlgPhase() { return dlgPhase; }
    public int getDlgIdx() { return dlgIdx; }
    public void setDlgIdx(int idx) { this.dlgIdx = idx; }
    public int getMenuSel() { return menuSel; }
    public void setMenuSel(int menuSel) { this.menuSel = menuSel; }
    public boolean isChestOpen() { return chestOpen; }
    public double getChestWX() { return chestWX; }
    public double getChestWY() { return chestWY; }
    public long getChestTime() { return chestTime; }
    public boolean isInCurrent() { return inCurrent; }
    public double getCurrentFx() { return currentFx; }
    public double getCurrentFy() { return currentFy; }
    public boolean isInPressureZone() { return inPressureZone; }
    public double getPressureBuoyMult() { return pressureBuoyMult; }
    public int getCurrentPhase() { return currentPhase; }
}
