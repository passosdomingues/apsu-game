package br.apsu.graphics;

import br.apsu.core.GameContext;
import br.apsu.model.boss.BossEntity;
import br.apsu.model.enemy.EnemyEntity;
import br.apsu.model.environment.Projectile;
import br.apsu.model.environment.SceneryElement;
import br.apsu.model.guardian.GuardianEntity;
import br.apsu.model.hero.HeroEntity;
import br.apsu.model.hero.HeroType;
import javafx.geometry.VPos;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;

/**
 * Renderizador mestre desacoplado.
 * Sprint 5: Bug B1 corrigido (aspecto estável no menu), novas fases P3-P5,
 * visualização de correntes, zonas de pressão, obstáculos vulcânicos.
 */
public class RenderEngine {

    private final SpriteManager spriteManager = SpriteManager.getInstance();
    private final LightingEngine lightingEngine = new LightingEngine();
    private final UIRenderer uiRenderer = new UIRenderer();

    // 2026-08-16: 4 estilos de ataque gerados por 01_adapa_ataque_variacoes.py
    // (mesma ordem de ATTACK_STYLES em _apsu_shared_lib.py). Ordem aqui só
    // precisa bater com os nomes das pastas de sprite, não com nada mais.
    private static final String[] ATTACK_STYLE_NAMES = {"thrust", "slash", "spin", "charge"};

    public void render(GraphicsContext gc, GameContext ctx, double width, double height) {
        gc.clearRect(0, 0, width, height);
        double t = ctx.getNanoTime() / 1_000_000_000.0;

        switch (ctx.getState()) {
            case MENU     -> drawMenu(gc, ctx, width, height, t);
            case DIALOGUE -> drawDialogue(gc, ctx, width, height, t);
            case P1       -> drawP1(gc, ctx, width, height, t);
            case P2       -> drawP2(gc, ctx, width, height, t);
            case P3       -> drawP3(gc, ctx, width, height, t);
            case P4       -> drawP4(gc, ctx, width, height, t);
            case P5       -> drawP5(gc, ctx, width, height, t);
            case WIN      -> drawEnd(gc, ctx, width, height, true);
            case OVER     -> drawEnd(gc, ctx, width, height, false);
        }

        if (ctx.isOverlayActive()) {
            int gt = Math.min(ctx.getOverlayGuardianType(), GuardianEntity.SPRITE_PATHS.length - 1);
            Image portrait = spriteManager.getImage(GuardianEntity.SPRITE_PATHS[gt]);
            uiRenderer.drawDialogueOverlay(gc, width, height, t, ctx.getOverlayName(),
                portrait, ctx.getOverlayLines(), ctx.getOverlayIdx(), ctx.getOverlayCharsShown());
        }
    }

    // =========================================================
    // B1-FIX — MENU: aspecto estável, sem oscilação de largura
    // =========================================================
    private void drawMenu(GraphicsContext gc, GameContext ctx, double width, double height, double timeSeconds) {
        drawGradientBackground(gc, width, height, "#040c1e", "#082040", "#0a3058");

        // Bolhas decorativas de fundo
        for (int i = 0; i < 22; i++) {
            double bx = (i * 87 + Math.sin(timeSeconds * 0.5 + i) * 38 + width * 6) % width;
            double by = (height - (timeSeconds * (16 + i % 7) + i * 68) % (height + 90));
            gc.setFill(Color.rgb(80, 180, 255, 0.09 + Math.sin(timeSeconds + i) * 0.03));
            gc.fillOval(bx, by, 6 + (i % 5) * 10, 6 + (i % 5) * 10);
        }

        gc.setTextAlign(TextAlignment.CENTER);
        gc.setTextBaseline(VPos.CENTER);

        gc.setFont(Font.font("Serif", FontWeight.BOLD, 64));
        gc.setFill(Color.rgb(0, 60, 160, 0.28)); gc.fillText("✦ AS ÁGUAS DE APSU ✦", width / 2.0 + 3, 105);
        gc.setFill(Color.web("#ffd700")); gc.fillText("✦ AS ÁGUAS DE APSU ✦", width / 2.0, 102);

        gc.setFont(Font.font("Serif", FontWeight.BOLD, 22));
        gc.setFill(Color.web("#70b8d8"));
        gc.fillText("A Lenda dos Apkallu", width / 2.0, 150);

        // B1-FIX: aspecto calculado da imagem ESTÁTICA (não do frame animado)
        HeroType hero = ctx.getHeroType();
        Image imgStatic = spriteManager.getImage(hero.getStaticSpritePath());

        // Calcula aspecto UMA VEZ a partir da imagem estática — nunca muda entre frames
        final double ph = 210;
        double aspect = (imgStatic != null && imgStatic.getHeight() > 0)
            ? imgStatic.getWidth() / imgStatic.getHeight()
            : 0.5;  // fallback seguro
        final double pw = ph * aspect; // LARGURA ESTÁVEL — não depende do frame animado

        double px = width * 0.82 - pw / 2.0, py = 150;

        // Agora carrega a animação apenas para o frame visual (aspecto JÁ está fixo)
        SpriteManager.FrameSeq fSwim = spriteManager.loadSequence(hero.getSwimDir(), 8.0, imgStatic);
        Image animFrame = fSwim.get(timeSeconds);
        if (animFrame == null) animFrame = imgStatic;

        drawShadow(gc, px + pw / 2, py + ph - 5, pw * 0.8, 14);

        // Bob senoidal suave (apenas Y, sem alterar escala/largura)
        gc.drawImage(animFrame, px, py + Math.sin(timeSeconds * 3) * 6, pw, ph);
        lightingEngine.drawBioluminescentHalo(gc, px + pw/2, py + ph/2, pw, hero.getAura());

        // Card Glassmorphic de Atributos
        gc.setFill(Color.rgb(4, 16, 36, 0.88));
        gc.fillRoundRect(px - 35, py + ph + 15, pw + 70, 145, 12, 12);
        gc.setStroke(Color.web(hero.getAuraHex()).deriveColor(0, 1, 1, 0.6)); gc.setLineWidth(1.5);
        gc.strokeRoundRect(px - 35, py + ph + 15, pw + 70, 145, 12, 12);

        gc.setTextAlign(TextAlignment.LEFT);
        gc.setFont(Font.font("Serif", FontWeight.BOLD, 14));
        gc.setFill(Color.web("#ffd700"));
        gc.fillText(hero.getName(), px - 25, py + ph + 35);

        drawStatBar(gc, "Velocidade",  hero.getMaxSpeed() / 16.5, px - 25, py + ph + 48,  pw + 50, Color.web("#4db8ff"));
        drawStatBar(gc, "Agilidade",   hero.getAccel()    / 3.2,  px - 25, py + ph + 72,  pw + 50, Color.web("#44cc88"));
        drawStatBar(gc, "Resistência", (hero.getDrag() - 0.85) / 0.12, px - 25, py + ph + 96, pw + 50, Color.web("#ffaa44"));
        drawStatBar(gc, "Poder Bolha", hero.getPwr()      / 1.6,  px - 25, py + ph + 120, pw + 50, Color.web("#e060ff"));

        // Menu 3 Opções
        gc.setTextAlign(TextAlignment.CENTER);
        String[] opts = {
            "◉  Dificuldade: " + ctx.getDifficulty().getLabel() + "  [◄ A / D ►]",
            "🦸  Herói: " + hero.getName() + "  [◄ A / D ►]",
            "▶  INICIAR JOGO"
        };
        double[] ys = {380, 455, 545};
        for (int i = 0; i < opts.length; i++) {
            boolean sel = (i == ctx.getMenuSel());
            if (sel) {
                gc.setFill(Color.rgb(0, 100, 220, 0.28));
                gc.fillRoundRect(width / 2.0 - 340, ys[i] - 32, 680, 62, 16, 16);
                gc.setStroke(Color.web("#ffd700")); gc.setLineWidth(2);
                gc.strokeRoundRect(width / 2.0 - 340, ys[i] - 32, 680, 62, 16, 16);
            }
            gc.setFont(Font.font("Serif", sel ? FontWeight.BOLD : FontWeight.NORMAL, sel ? 28 : 22));
            gc.setFill(sel ? Color.web("#ffd700") : Color.web("#78b4cc"));
            gc.fillText(opts[i], width / 2.0, ys[i]);
        }

        gc.setFont(Font.font("Serif", 15));
        gc.setFill(Color.web("#ffd700"));
        gc.fillText(ctx.getDifficulty().getDescription(), width / 2.0, 625);
    }

    private void drawStatBar(GraphicsContext gc, String label, double ratio, double x, double y, double width, Color color) {
        gc.setFont(Font.font("Serif", 11));
        gc.setFill(Color.web("#a0c0e0"));
        gc.fillText(label, x, y + 10);
        double barX = x + 70, barW = width - 70, barH = 10;
        gc.setFill(Color.rgb(8, 24, 48, 0.9));
        gc.fillRoundRect(barX, y + 2, barW, barH, 4, 4);
        gc.setFill(color);
        gc.fillRoundRect(barX, y + 2, barW * Math.max(0.1, Math.min(1.0, ratio)), barH, 4, 4);
        gc.setStroke(color.deriveColor(0, 1, 1, 0.5)); gc.setLineWidth(1);
        gc.strokeRoundRect(barX, y + 2, barW, barH, 4, 4);
    }

    private void drawDialogue(GraphicsContext gc, GameContext ctx, double width, double height, double timeSeconds) {
        drawGradientBackground(gc, width, height, "#030a14", "#081226", "#0a1e3c");

        Image enkiImg = switch (ctx.getDlgPhase()) {
            case 1 -> spriteManager.getImage("sprites/enki/03_enki_var_eremita.png");
            case 2 -> spriteManager.getImage("sprites/enki/03_enki_var_celestial.png");
            case 4 -> spriteManager.getImage("sprites/enki/03_enki_npc.png"); // Enki em pessoa na F5
            default -> spriteManager.getImage("sprites/enki/03_enki_npc.png");
        };

        if (enkiImg != null) {
            double eh2 = 320, ew2 = eh2 * 0.49;
            double bob = Math.sin(timeSeconds * 2.5) * 6;
            gc.drawImage(enkiImg, 35, height / 2.0 - eh2 / 2 - 30 + bob, ew2, eh2);
        }

        gc.setFill(Color.rgb(4, 10, 28, 0.94));
        gc.fillRoundRect(240, height / 2.0 - 150, width - 310, 295, 22, 22);
        gc.setStroke(Color.web("#0e3888")); gc.setLineWidth(2);
        gc.strokeRoundRect(240, height / 2.0 - 150, width - 310, 295, 22, 22);
        gc.setTextAlign(TextAlignment.LEFT);
        gc.setFont(Font.font("Serif", FontWeight.BOLD, 20));
        gc.setFill(Color.web("#60a0e0"));
        gc.fillText("Enki — Senhor das Águas Primordiais:", 265, height / 2.0 - 118);
        gc.setFill(Color.WHITE); gc.setFont(Font.font("Serif", 20));
        String[] currentDlg = GuardianEntity.DIALOGUES[Math.min(ctx.getDlgPhase(), GuardianEntity.DIALOGUES.length - 1)];
        if (ctx.getDlgIdx() < currentDlg.length) uiRenderer.wrapText(gc, currentDlg[ctx.getDlgIdx()], 265, height / 2.0 - 76, width - 440, 34);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.setFill(Color.web("#ffd700")); gc.setFont(Font.font("Serif", 15));
        gc.fillText("[ ESPAÇO / E: Avançar  •  ESC: Pular Diálogo ]", width / 2.0 + 80, height / 2.0 + 136);
    }

    private void drawParallaxBackground(GraphicsContext gc, Image bg, double cameraX, double width, double height, double parallaxFactor) {
        if (bg == null) return;
        double bgH = height;
        double bgW = bg.getWidth() * (bgH / Math.max(1.0, bg.getHeight()));
        if (bgW <= 0) bgW = width;
        double offset = -(cameraX * parallaxFactor) % bgW;
        if (offset > 0) offset -= bgW;
        for (double x = offset; x < width + bgW; x += bgW) {
            gc.drawImage(bg, x, 0, bgW, bgH);
        }
    }

    // =========================================================
    // FASE 1 — Águas Claras
    // =========================================================
    private void drawP1(GraphicsContext gc, GameContext ctx, double width, double height, double timeSeconds) {
        Image bg1 = spriteManager.getImage("bg1.png");
        if (bg1 != null) {
            drawParallaxBackground(gc, bg1, ctx.getCamera().getX(), width, height, 0.40);
        } else {
            drawGradientBackground(gc, width, height, "#08192e", "#0e3050", "#144870");
        }

        lightingEngine.drawSunCaustics(gc, width, height, timeSeconds);
        gc.setFill(Color.rgb(8, 30, 16, 0.90)); gc.fillRect(0, height - 28, width, 28);

        // Cenário
        for (SceneryElement elem : ctx.getSceneryElements()) {
            double cx = ctx.getCamera().toScreenX(elem.getWorldX());
            if (cx < -150 || cx > width + 150) continue;
            if (elem.getType() == SceneryElement.Type.GEYSER) {
                lightingEngine.drawGeyserHeatGlow(gc, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight());
                drawGeyserParticles(gc, cx + elem.getWidth()/2, elem.getWorldY(), timeSeconds, Color.AQUA);
            }
        }

        for (GuardianEntity g : ctx.getGuardians()) {
            double gx = ctx.getCamera().toScreenX(g.getWorldX());
            drawGuardian(gc, gx, g.getWorldY(), g.getType(), !g.isContacted(), timeSeconds);
        }

        drawPortal(gc, ctx.getCamera().toScreenX(4000 - 100), ctx.getTabletsCollected() >= 1, height, timeSeconds);

        for (EnemyEntity e : ctx.getEnemies()) {
            if (!e.isAlive()) continue;
            drawEnemy(gc, ctx.getCamera().toScreenX(e.getWorldX()), e.getCurrentY(), e.getType().getId(), timeSeconds);
        }

        drawProjectiles(gc, ctx);
        drawHero(gc, ctx.getCamera().toScreenX(ctx.getHero().getX()), ctx.getHero().getY(), ctx.getHero(), timeSeconds);
        ctx.getParticleSystem().render(gc);

        uiRenderer.drawHUD(gc, ctx.getHero(), ctx.getTabletsCollected(), "Fase 1 — Águas Claras", ctx.getDifficulty());
        drawAlert(gc, ctx, width, height);
    }

    // =========================================================
    // FASE 2 — Cavernas de Coral
    // =========================================================
    private void drawP2(GraphicsContext gc, GameContext ctx, double width, double height, double timeSeconds) {
        Image bg2 = spriteManager.getImage("bg2.png");
        if (bg2 != null) {
            drawParallaxBackground(gc, bg2, ctx.getCamera().getX(), width, height, 0.40);
        } else {
            drawGradientBackground(gc, width, height, "#040c16", "#081826", "#0a2234");
        }

        // Galeão e Baú
        double csx = ctx.getCamera().toScreenX(ctx.getChestWX());
        if (csx > -300 && csx < width + 300) {
            Image galeao3D = spriteManager.getImage("sprites/scenery/07_navio_naufragado_elemento-cenario.png");
            if (galeao3D != null) {
                gc.drawImage(galeao3D, csx - 180, ctx.getChestWY() - 140, 450, 260);
            } else {
                gc.setFill(Color.rgb(12, 28, 48, 0.75));
                gc.fillPolygon(new double[]{csx - 140, csx - 40, csx + 180, csx + 130},
                               new double[]{ctx.getChestWY() + 80, ctx.getChestWY() - 60, ctx.getChestWY() - 60, ctx.getChestWY() + 80}, 4);
            }

            boolean open = ctx.isChestOpen();
            Image bau3D = spriteManager.getImage("sprites/scenery/06_bau_tesouro_elemento-cenario.png");
            if (bau3D != null) {
                gc.drawImage(bau3D, csx - 40, ctx.getChestWY() - 35, 100, 75);
            } else {
                gc.setFill(open ? Color.web("#ffd700") : Color.web("#8b5a2b"));
                gc.fillRoundRect(csx - 30, ctx.getChestWY() - 25, 60, 45, 10, 10);
            }

            if (open) {
                lightingEngine.drawBioluminescentHalo(gc, csx + 10, ctx.getChestWY(), 95, Color.GOLD);
            } else {
                gc.setFill(Color.rgb(0, 12, 28, 0.88));
                gc.fillRoundRect(csx - 70, ctx.getChestWY() - 62, 140, 24, 8, 8);
                gc.setFill(Color.web("#ffd700")); gc.setFont(Font.font("Serif", FontWeight.BOLD, 12));
                gc.setTextAlign(TextAlignment.CENTER);
                gc.fillText("[ E / ESPAÇO: BAÚ ]", csx, ctx.getChestWY() - 46);
            }
        }

        // Coral e obstáculos
        for (SceneryElement elem : ctx.getSceneryElements()) {
            double cx = ctx.getCamera().toScreenX(elem.getWorldX());
            if (cx < -120 || cx > width + 120) continue;

            if (elem.getType() == SceneryElement.Type.CORAL) {
                gc.setFill(Color.rgb(6, 20, 36, 0.94));
                gc.fillRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 14, 14);
                gc.setStroke(Color.web("#00f0ff")); gc.setLineWidth(3.0);
                gc.strokeRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 14, 14);

                Image coral3D = spriteManager.getImage("sprites/scenery/10_perigos_e_obstaculos_cenario.png");
                if (coral3D != null) {
                    gc.setGlobalAlpha(0.65);
                    gc.drawImage(coral3D, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight());
                    gc.setGlobalAlpha(1.0);
                }
                double glowY = (elem.getWorldY() == 0) ? elem.getHeight() - 15 : elem.getWorldY() + 15;
                lightingEngine.drawBioluminescentHalo(gc, cx + elem.getWidth()/2, glowY, 50, Color.web("#00ffff"));

            } else if (elem.getType() == SceneryElement.Type.GEYSER) {
                lightingEngine.drawGeyserHeatGlow(gc, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight());
                drawGeyserParticles(gc, cx + elem.getWidth()/2, elem.getWorldY(), timeSeconds, Color.AQUA);
            }
        }

        for (GuardianEntity g : ctx.getGuardians()) {
            double gx = ctx.getCamera().toScreenX(g.getWorldX());
            drawGuardian(gc, gx, g.getWorldY(), g.getType(), !g.isContacted(), timeSeconds);
        }

        drawPortal(gc, ctx.getCamera().toScreenX(4000 - 100), ctx.getTabletsCollected() >= 2, height, timeSeconds);

        for (EnemyEntity e : ctx.getEnemies()) {
            if (!e.isAlive()) continue;
            drawEnemy(gc, ctx.getCamera().toScreenX(e.getWorldX()), e.getCurrentY(), e.getType().getId(), timeSeconds);
        }

        drawProjectiles(gc, ctx);
        drawHero(gc, ctx.getCamera().toScreenX(ctx.getHero().getX()), ctx.getHero().getY(), ctx.getHero(), timeSeconds);
        ctx.getParticleSystem().render(gc);

        uiRenderer.drawHUD(gc, ctx.getHero(), ctx.getTabletsCollected(), "Fase 2 — Cavernas de Coral", ctx.getDifficulty());
        drawAlert(gc, ctx, width, height);
    }

    // =========================================================
    // FASE 3 — Correntes Abissais
    // =========================================================
    private void drawP3(GraphicsContext gc, GameContext ctx, double width, double height, double timeSeconds) {
        Image bg3 = spriteManager.getImage("bg3.png");
        if (bg3 != null) {
            drawParallaxBackground(gc, bg3, ctx.getCamera().getX(), width, height, 0.35);
        } else {
            drawGradientBackground(gc, width, height, "#060012", "#110028", "#1a0040");
        }

        // Renderizar elementos ambientais
        for (SceneryElement elem : ctx.getSceneryElements()) {
            double cx = ctx.getCamera().toScreenX(elem.getWorldX());
            if (cx < -200 || cx > width + 200) continue;

            switch (elem.getType()) {
                case CURRENT -> drawCurrentZone(gc, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(),
                                                elem.getCurrentVx(), elem.getCurrentVy(), timeSeconds);
                case PRESSURE_ZONE -> drawPressureZone(gc, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(),
                                                        elem.getBuoyancyMult(), timeSeconds);
                case MOVING_OBSTACLE -> {
                    // 2026-08-16: era só o retângulo com contorno roxo (o
                    // "efeito portal" que o Rafa reclamou) — agora usa o
                    // asset 3D novo (13_obstaculo_abissal.py, crescimento
                    // corrompido pela peçonha de Kullullû), mesmo padrão
                    // já aplicado na Fase 4 com a rocha vulcânica.
                    Image obstaculo3D = spriteManager.getImage("sprites/scenery/13_obstaculo_abissal.png");
                    if (obstaculo3D != null) {
                        gc.drawImage(obstaculo3D, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight());
                    } else {
                        gc.setFill(Color.rgb(30, 15, 60, 0.92));
                        gc.fillRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 12, 12);
                        gc.setStroke(Color.web("#8040ff")); gc.setLineWidth(2.5);
                        gc.strokeRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 12, 12);
                    }
                    lightingEngine.drawBioluminescentHalo(gc, cx + elem.getWidth()/2, elem.getWorldY() + elem.getHeight()/2,
                        elem.getWidth() * 0.5, Color.web("#6020cc"));
                }
                case GEYSER -> {
                    lightingEngine.drawGeyserHeatGlow(gc, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight());
                    drawGeyserParticles(gc, cx + elem.getWidth()/2, elem.getWorldY(), timeSeconds, Color.CYAN);
                }
                default -> {}
            }
        }

        // Indicador visual de corrente ativa no herói
        if (ctx.isInCurrent()) {
            drawCurrentArrowOnHero(gc, ctx, timeSeconds);
        }

        for (GuardianEntity g : ctx.getGuardians()) {
            double gx = ctx.getCamera().toScreenX(g.getWorldX());
            drawGuardian(gc, gx, g.getWorldY(), g.getType(), !g.isContacted(), timeSeconds);
        }

        drawPortal(gc, ctx.getCamera().toScreenX(4000 - 100), ctx.getTabletsCollected() >= 3, height, timeSeconds);

        for (EnemyEntity e : ctx.getEnemies()) {
            if (!e.isAlive()) continue;
            drawEnemy(gc, ctx.getCamera().toScreenX(e.getWorldX()), e.getCurrentY(), e.getType().getId(), timeSeconds);
        }

        drawProjectiles(gc, ctx);
        drawHero(gc, ctx.getCamera().toScreenX(ctx.getHero().getX()), ctx.getHero().getY(), ctx.getHero(), timeSeconds);
        ctx.getParticleSystem().render(gc);

        uiRenderer.drawHUD(gc, ctx.getHero(), ctx.getTabletsCollected(), "Fase 3 — Correntes Abissais", ctx.getDifficulty());
        drawAlert(gc, ctx, width, height);
    }

    // =========================================================
    // FASE 4 — Abismo Vulcânico
    // =========================================================
    private void drawP4(GraphicsContext gc, GameContext ctx, double width, double height, double timeSeconds) {
        Image bg4 = spriteManager.getImage("bg4.png");
        if (bg4 != null) {
            drawParallaxBackground(gc, bg4, ctx.getCamera().getX(), width, height, 0.30);
        } else {
            drawGradientBackground(gc, width, height, "#1a0500", "#380800", "#5a0a00");
        }

        // Brilho de lava no fundo
        for (int i = 0; i < 8; i++) {
            double gx = (i * 180 + timeSeconds * 15 + 50) % (width + 200) - 100;
            double gy = height - 80 + Math.sin(timeSeconds * 1.2 + i) * 20;
            gc.setFill(Color.rgb(255, 80, 0, 0.08 + Math.sin(timeSeconds * 2 + i) * 0.04));
            gc.fillOval(gx - 60, gy - 20, 120, 40);
        }

        // Elementos do cenário
        for (SceneryElement elem : ctx.getSceneryElements()) {
            double cx = ctx.getCamera().toScreenX(elem.getWorldX());
            if (cx < -200 || cx > width + 200) continue;

            switch (elem.getType()) {
                case LAVA_POOL -> {
                    // Lava pulsante
                    double pulse = 0.85 + Math.sin(timeSeconds * 3 + elem.getWorldX() * 0.01) * 0.15;
                    gc.setFill(new LinearGradient(cx, elem.getWorldY(), cx, elem.getWorldY() + elem.getHeight(), false,
                        CycleMethod.NO_CYCLE,
                        new Stop(0, Color.rgb(255, 100, 0, 0.9 * pulse)),
                        new Stop(1, Color.rgb(200, 20, 0, 0.95 * pulse))));
                    gc.fillRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 8, 8);
                    gc.setStroke(Color.rgb(255, 200, 0, 0.8)); gc.setLineWidth(2.0);
                    gc.strokeRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 8, 8);
                    // Bolhas de lava
                    for (int b = 0; b < 3; b++) {
                        double bx2 = cx + (b * 0.3 + 0.2) * elem.getWidth() + Math.sin(timeSeconds * 2 + b) * 10;
                        double by2 = elem.getWorldY() - 5 + Math.sin(timeSeconds * 3 + b) * 6;
                        gc.setFill(Color.rgb(255, 150, 0, 0.7));
                        gc.fillOval(bx2 - 5, by2 - 5, 10, 10);
                    }
                }
                case VOLCANIC_ROCK -> {
                    // 2026-08-16: antes era só um retângulo com contorno
                    // laranja ("efeito portal" que o Rafa reclamou) — agora
                    // usa o asset 3D real (12_obstaculo_vulcanico.py), que
                    // já existia mas nunca tinha sido carregado no Java.
                    Image rocha3D = spriteManager.getImage("sprites/scenery/12_obstaculo_vulcanico.png");
                    if (rocha3D != null) {
                        gc.drawImage(rocha3D, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight());
                    } else {
                        gc.setFill(Color.rgb(28, 12, 6, 0.95));
                        gc.fillRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 10, 10);
                        gc.setStroke(Color.rgb(180, 60, 0, 0.8)); gc.setLineWidth(2.5);
                        gc.strokeRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 10, 10);
                    }
                    // Fissuras incandescentes — mantido como acento por cima do asset
                    double glowStrength = 0.6 + Math.sin(timeSeconds * 2 + elem.getWorldX()) * 0.3;
                    gc.setFill(Color.rgb(255, 60, 0, glowStrength * 0.5));
                    gc.fillOval(cx + elem.getWidth()*0.2, elem.getWorldY() + elem.getHeight()*0.4, elem.getWidth()*0.6, 6);
                }
                case MOVING_OBSTACLE -> {
                    // Rocha vulcânica móvel — 2026-08-16: mesmo asset 3D da
                    // VOLCANIC_ROCK acima, em vez do retângulo-portal antigo.
                    Image rocha3D = spriteManager.getImage("sprites/scenery/12_obstaculo_vulcanico.png");
                    if (rocha3D != null) {
                        gc.drawImage(rocha3D, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight());
                    } else {
                        gc.setFill(Color.rgb(35, 15, 5, 0.95));
                        gc.fillRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 12, 12);
                        gc.setStroke(Color.rgb(255, 120, 0, 0.9)); gc.setLineWidth(3.0);
                        gc.strokeRoundRect(cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(), 12, 12);
                    }
                    lightingEngine.drawBioluminescentHalo(gc,
                        cx + elem.getWidth()/2, elem.getWorldY() + elem.getHeight()/2,
                        elem.getWidth() * 0.55, Color.web("#ff4400"));
                }
                case GEYSER -> {
                    lightingEngine.drawGeyserHeatGlow(gc, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight());
                    drawGeyserParticles(gc, cx + elem.getWidth()/2, elem.getWorldY(), timeSeconds, Color.ORANGERED);
                }
                case CURRENT -> {
                    // Correntes de calor ascendentes
                    drawCurrentZone(gc, cx, elem.getWorldY(), elem.getWidth(), elem.getHeight(),
                                    elem.getCurrentVx(), elem.getCurrentVy(), timeSeconds);
                }
                default -> {}
            }
        }

        if (ctx.isInCurrent()) {
            drawCurrentArrowOnHero(gc, ctx, timeSeconds);
        }

        for (GuardianEntity g : ctx.getGuardians()) {
            double gx = ctx.getCamera().toScreenX(g.getWorldX());
            drawGuardian(gc, gx, g.getWorldY(), g.getType(), !g.isContacted(), timeSeconds);
        }

        drawPortal(gc, ctx.getCamera().toScreenX(4000 - 100), ctx.getTabletsCollected() >= 4, height, timeSeconds);

        for (EnemyEntity e : ctx.getEnemies()) {
            if (!e.isAlive()) continue;
            drawEnemy(gc, ctx.getCamera().toScreenX(e.getWorldX()), e.getCurrentY(), e.getType().getId(), timeSeconds);
        }

        drawProjectiles(gc, ctx);
        drawHero(gc, ctx.getCamera().toScreenX(ctx.getHero().getX()), ctx.getHero().getY(), ctx.getHero(), timeSeconds);
        ctx.getParticleSystem().render(gc);

        uiRenderer.drawHUD(gc, ctx.getHero(), ctx.getTabletsCollected(), "Fase 4 — Abismo Vulcânico", ctx.getDifficulty());
        drawAlert(gc, ctx, width, height);
    }

    // =========================================================
    // FASE 5 — Templo Final de Apsu (arena boss)
    // =========================================================
    private void drawP5(GraphicsContext gc, GameContext ctx, double width, double height, double timeSeconds) {
        Image bg5 = spriteManager.getImage("bg5.png");
        if (bg5 != null) {
            gc.drawImage(bg5, 0, 0, width, height);
        } else {
            drawGradientBackground(gc, width, height, "#080018", "#150030", "#200050");
        }

        // Colunas de Atlantis
        Image ruinas = spriteManager.getImage("sprites/scenery/09_ruinas_e_colunas_atlantis.png");
        if (ruinas != null) {
            gc.setGlobalAlpha(0.55);
            gc.drawImage(ruinas, 20, 50, 220, 500);
            gc.setGlobalAlpha(0.4);
            gc.drawImage(ruinas, width - 240, 50, 220, 500);
            gc.setGlobalAlpha(1.0);
        }

        // Correntes e zonas na arena
        for (SceneryElement elem : ctx.getSceneryElements()) {
            if (elem.getType() == SceneryElement.Type.CURRENT) {
                drawCurrentZone(gc, elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight(),
                                elem.getCurrentVx(), elem.getCurrentVy(), timeSeconds);
            } else if (elem.getType() == SceneryElement.Type.PRESSURE_ZONE) {
                drawPressureZone(gc, elem.getWorldX(), elem.getWorldY(), elem.getWidth(), elem.getHeight(),
                                  elem.getBuoyancyMult(), timeSeconds);
            }
        }

        for (GuardianEntity g : ctx.getGuardians()) {
            drawGuardian(gc, g.getWorldX(), g.getWorldY(), g.getType(), !g.isContacted(), timeSeconds);
        }

        if (ctx.getBoss() != null) {
            drawBoss(gc, ctx.getBoss(), timeSeconds);
        }

        drawProjectiles(gc, ctx);
        drawHero(gc, ctx.getHero().getX(), ctx.getHero().getY(), ctx.getHero(), timeSeconds);
        ctx.getParticleSystem().render(gc);

        uiRenderer.drawHUD(gc, ctx.getHero(), ctx.getTabletsCollected(), "Fase 5 — Templo de Apsu", ctx.getDifficulty());
        drawAlert(gc, ctx, width, height);
    }

    // =========================================================
    // ELEMENTOS VISUAIS AMBIENTAIS
    // =========================================================

    /** Zona de corrente de água — setas de direção animadas. */
    private void drawCurrentZone(GraphicsContext gc, double x, double y, double w, double h,
                                  double vx, double vy, double t) {
        // Fundo semitransparente azul/turquesa
        double angle = Math.atan2(vy, vx);
        Color zoneColor = (vy < 0) ? Color.rgb(0, 200, 255, 0.12) : Color.rgb(0, 100, 200, 0.12);
        gc.setFill(zoneColor);
        gc.fillRoundRect(x, y, w, h, 10, 10);
        gc.setStroke(Color.rgb(0, 200, 255, 0.35)); gc.setLineWidth(1.5);
        gc.strokeRoundRect(x, y, w, h, 10, 10);

        // Setas animadas na direção da corrente
        double cx = x + w / 2, cy = y + h / 2;
        int numArrows = 5;
        double spacing = Math.max(w, h) / (numArrows + 1);
        for (int i = 0; i < numArrows; i++) {
            double progress = (i / (double) numArrows + t * 0.5) % 1.0;
            double ax = cx + Math.cos(angle) * (progress - 0.5) * Math.max(w, h);
            double ay = cy + Math.sin(angle) * (progress - 0.5) * Math.max(w, h);
            double alpha = 0.15 + progress * 0.7;
            gc.setFill(Color.rgb(0, 220, 255, alpha));
            gc.fillOval(ax - 4, ay - 4, 8, 8);
        }
    }

    /** Zona de empuxo variável — halos pulsantes. */
    private void drawPressureZone(GraphicsContext gc, double x, double y, double w, double h,
                                   double buoyMult, double t) {
        Color color = (buoyMult > 1.0) ? Color.rgb(0, 255, 150, 0.10) : Color.rgb(180, 0, 255, 0.10);
        Color strokeColor = (buoyMult > 1.0) ? Color.rgb(0, 255, 150, 0.4) : Color.rgb(200, 0, 255, 0.4);
        String label = (buoyMult > 1.0) ? "▲ EMPUXO ▲" : "▼ PRESSÃO ▼";

        gc.setFill(color);
        gc.fillRoundRect(x, y, w, h, 10, 10);

        // Borda pulsante
        double pulse = 0.3 + Math.sin(t * 3.5) * 0.15;
        gc.setStroke(strokeColor.deriveColor(0, 1, 1, pulse + 0.2)); gc.setLineWidth(2.5);
        gc.strokeRoundRect(x, y, w, h, 10, 10);

        // Label
        gc.setFont(Font.font("Serif", FontWeight.BOLD, 12));
        gc.setFill(strokeColor.deriveColor(0, 1, 1, 0.8));
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText(label, x + w/2, y + h/2 + 5);
    }

    /** Partículas do gêiser ascendendo. */
    private void drawGeyserParticles(GraphicsContext gc, double cx, double baseY, double t, Color color) {
        for (int i = 0; i < 6; i++) {
            double progress = ((t * 1.2 + i * 0.18) % 1.0);
            double px = cx + Math.sin(t * 3 + i * 1.1) * 18;
            double py = baseY - progress * 160;
            double alpha = (1.0 - progress) * 0.7;
            double r = (1.0 - progress) * 6 + 2;
            gc.setFill(color.deriveColor(0, 1, 1, alpha));
            gc.fillOval(px - r, py - r, r * 2, r * 2);
        }
    }

    /** Seta de corrente sobre o herói quando está em corrente ativa. */
    private void drawCurrentArrowOnHero(GraphicsContext gc, GameContext ctx, double t) {
        double hx, hy;
        boolean isP5 = (ctx.getState() == GameContext.State.P5);
        hx = isP5 ? ctx.getHero().getX() : ctx.getCamera().toScreenX(ctx.getHero().getX());
        hy = ctx.getHero().getY();

        double fx = ctx.getCurrentFx(), fy = ctx.getCurrentFy();
        double angle = Math.atan2(fy, fx);
        double pulse = 0.8 + Math.sin(t * 5) * 0.2;
        double arrowX = hx + HeroEntity.HW/2 + Math.cos(angle) * 40;
        double arrowY = hy + HeroEntity.HH/2 + Math.sin(angle) * 40;

        gc.setFill(Color.rgb(0, 220, 255, pulse * 0.85));
        gc.fillOval(arrowX - 10, arrowY - 10, 20, 20);
        gc.setFont(Font.font("Serif", FontWeight.BOLD, 13));
        gc.setFill(Color.rgb(0, 255, 255, pulse));
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText("⟹", arrowX, arrowY + 4);
    }

    // =========================================================
    // HERÓI
    // =========================================================
    private void drawHero(GraphicsContext gc, double x, double y, HeroEntity hero, double timeSeconds) {
        if (hero.isInvulnerable() && (long)(timeSeconds * 10) % 2 == 0) return;

        boolean shooting = hero.isShooting();
        String staticPath, animDir;

        if (shooting) {
            // 2026-08-16: 4 estilos de ataque novos (thrust/slash/spin/charge)
            // substituem as 2 poses antigas de tiro de bolha — decisão do Rafa
            // ("as duas antigas estavam malfeitas, a horizontal é a pior").
            // Cicla a cada tiro (attackStyleIndex, incrementado em
            // HeroEntity.triggerShooting) em vez de alternar só 2 poses.
            // Fallback estático continua o sprite normal do herói — sempre
            // carregado, nunca nulo — não precisa de um path por estilo.
            String style = ATTACK_STYLE_NAMES[hero.getAttackStyleIndex() % ATTACK_STYLE_NAMES.length];
            staticPath = hero.getType().getStaticSpritePath();
            animDir = "sprites/adapa/01_adapa_ataque_" + style;
        } else {
            staticPath = hero.getType().getStaticSpritePath();
            animDir = hero.getType().getSwimDir();
        }

        Image fallback = spriteManager.getImage(staticPath);
        // B1-FIX (no gameplay): aspecto do herói calculado da imagem estática, não do frame
        final double targetH = HeroEntity.HH;
        double aspect = (fallback != null && fallback.getHeight() > 0)
            ? fallback.getWidth() / fallback.getHeight() : 0.5;
        double targetW = Math.min(210.0, Math.max(60.0, targetH * aspect));

        SpriteManager.FrameSeq fSeq = spriteManager.loadSequence(animDir, 8.0, fallback);
        Image frame = fSeq.get(timeSeconds);
        if (frame == null) frame = fallback;

        drawShadow(gc, x + HeroEntity.HW / 2, y + HeroEntity.HH - 3, targetW * 0.55, 12);

        gc.save();
        gc.translate(x + HeroEntity.HW / 2, y + HeroEntity.HH / 2);
        gc.rotate(hero.getPitchAngle());
        if (!hero.isFacingRight()) gc.scale(-1, 1);
        // Squash & stretch (auditoria 2026-08-15): reforça peso/impulso na água
        // em cima de qualquer frame de sprite, sem precisar de arte extra.
        gc.scale(hero.getSquashX(), hero.getSquashY());

        if (frame != null) {
            gc.drawImage(frame, -targetW / 2, -targetH / 2, targetW, targetH);
        } else {
            gc.setFill(hero.getType().getAura());
            gc.fillRoundRect(-HeroEntity.HW / 2, -HeroEntity.HH / 2, HeroEntity.HW, HeroEntity.HH, 8, 8);
        }
        gc.restore();

        lightingEngine.drawBioluminescentHalo(gc, x + HeroEntity.HW/2, y + HeroEntity.HH/2,
            targetW * 0.7, hero.getType().getAura());
    }

    // =========================================================
    // INIMIGOS
    // =========================================================
    private void drawEnemy(GraphicsContext gc, double x, double y, int typeId, double timeSeconds) {
        br.apsu.model.enemy.EnemyType eType = br.apsu.model.enemy.EnemyType.fromId(typeId);
        Image fallback = spriteManager.getImage(eType.getStaticSprite());
        SpriteManager.FrameSeq fSeq = spriteManager.loadSequence(eType.getAnimDir(), 8.0, fallback);
        Image frame = fSeq.get(timeSeconds);
        if (frame == null) frame = fallback;

        double ew = eType.getWidth();
        double eh = eType.getHeight();

        drawShadow(gc, x + ew / 2, y + eh - 2, ew * 0.65, 9);
        if (frame != null) {
            gc.save();
            gc.translate(x + ew / 2, y + eh / 2);
            // Squash & stretch (2026-08-16): pulso sutil ligado ao próprio
            // movimento de bob vertical que já existe (EnemyEntity.update);
            // não precisa de estado novo — só um seno amarrado à posição
            // de tela + tipo, pra cada inimigo pulsar fora de sincronia
            // com os outros, em vez de todos piscando juntos.
            double squashPulse = Math.sin(timeSeconds * 3.2 + x * 0.02 + typeId * 1.7) * 0.06;
            gc.scale(1.0 - squashPulse, 1.0 + squashPulse);
            // Enguia (1) e Caranguejo (3) foram renderizados virados para a direita no Blender
            if (typeId == 1 || typeId == 3) {
                gc.scale(-1, 1);
            }
            // Arraia (4) — leve rotação para parecer planando
            if (typeId == 4) {
                gc.rotate(-8 + Math.sin(timeSeconds * 2.0) * 4);
            }
            gc.drawImage(frame, -ew / 2, -eh / 2, ew, eh);
            gc.restore();
        } else {
            // Fallback geométrico por tipo
            Color fallbackColor = switch (typeId) {
                case 1 -> Color.web("#0060ff");  // Enguia — azul elétrico
                case 2 -> Color.web("#aa00ff");  // Medusa — roxo
                case 3 -> Color.web("#cc3300");  // Caranguejo — vermelho
                case 4 -> Color.web("#004488");  // Arraia — azul escuro
                case 5 -> Color.web("#660099");  // Leviatã — roxo profundo
                default -> Color.web("#006600"); // Peixe — verde
            };
            gc.setFill(fallbackColor);
            if (typeId == 1) {
                // Enguia — forma horizontal
                gc.fillRoundRect(x, y + eh/4, ew, eh/2, 8, 8);
            } else if (typeId == 4) {
                // Arraia — forma diamante/losango
                gc.fillPolygon(new double[]{x + ew/2, x + ew, x + ew/2, x},
                               new double[]{y, y + eh/2, y + eh, y + eh/2}, 4);
            } else {
                gc.fillOval(x, y, ew, eh);
            }
        }
    }

    // =========================================================
    // BOSS
    // =========================================================
    private void drawBoss(GraphicsContext gc, BossEntity boss, double timeSeconds) {
        String bossStatic = switch (boss.getVariant()) {
            case 1 -> "sprites/kullullu/02_kullullu_var_glacial.png";
            case 2 -> "sprites/kullullu/02_kullullu_var_toxico.png";
            default -> "sprites/kullullu/02_kullullu_boss.png";
        };
        String bossAnimDir = switch (boss.getVariant()) {
            case 1 -> "sprites/kullullu/02_kullullu_var_glacial";
            case 2 -> "sprites/kullullu/02_kullullu_var_toxico";
            default -> "sprites/kullullu/02_kullullu_boss";
        };
        Image fallback = spriteManager.getImage(bossStatic);
        SpriteManager.FrameSeq fSeq = spriteManager.loadSequence(bossAnimDir, 6.0, fallback);
        Image frame = fSeq.get(timeSeconds);
        if (frame == null) frame = fallback;

        drawShadow(gc, boss.getX() + BossEntity.BW / 2, boss.getY() + BossEntity.BH - 5, BossEntity.BW * 0.7, 22);
        if (frame != null) {
            // Squash & stretch (2026-08-16) — respiração de predador, mesma
            // ideia da vida idle já aplicada no modelo 3D (02_kullullu_boss.py),
            // só que aqui reforça no lado do jogo também (frequência um
            // pouco mais lenta/pesada que os inimigos comuns).
            gc.save();
            gc.translate(boss.getX() + BossEntity.BW / 2, boss.getY() + BossEntity.BH / 2);
            double breathe = Math.sin(timeSeconds * 1.6) * 0.035;
            gc.scale(1.0 - breathe, 1.0 + breathe);
            gc.drawImage(frame, -BossEntity.BW / 2, -BossEntity.BH / 2, BossEntity.BW, BossEntity.BH);
            gc.restore();
        }

        // Barra de vida do boss
        double hpRatio = (double) boss.getHp() / boss.getMaxHp();
        double barW = BossEntity.BW * 0.9;
        double barX = boss.getX() + BossEntity.BW * 0.05;
        double barY = boss.getY() - 18;
        gc.setFill(Color.rgb(20, 0, 0, 0.8));
        gc.fillRoundRect(barX, barY, barW, 10, 4, 4);
        gc.setFill(hpRatio > 0.5 ? Color.web("#ff4444") : Color.web("#ff8800"));
        gc.fillRoundRect(barX, barY, barW * hpRatio, 10, 4, 4);
        gc.setStroke(Color.rgb(255, 60, 60, 0.7)); gc.setLineWidth(1.5);
        gc.strokeRoundRect(barX, barY, barW, 10, 4, 4);
    }

    private void drawGuardian(GraphicsContext gc, double x, double y, int type, boolean prompt, double timeSeconds) {
        int safeType = Math.min(type, GuardianEntity.SPRITE_PATHS.length - 1);
        String gStatic = GuardianEntity.SPRITE_PATHS[safeType];
        String gAnimDir = gStatic.substring(0, gStatic.lastIndexOf('.'));
        Image fallback = spriteManager.getImage(gStatic);
        SpriteManager.FrameSeq fSeq = spriteManager.loadSequence(gAnimDir, 4.0, fallback);
        Image frame = fSeq.get(timeSeconds);
        if (frame == null) frame = fallback;

        lightingEngine.drawBioluminescentHalo(gc, x + GuardianEntity.GW / 2, y + GuardianEntity.GH / 2,
            GuardianEntity.GW * 0.9, Color.web("#40e0ff"));
        drawShadow(gc, x + GuardianEntity.GW / 2, y + GuardianEntity.GH - 4, GuardianEntity.GW * 0.7, 16);

        if (frame != null) {
            gc.drawImage(frame, x, y, GuardianEntity.GW, GuardianEntity.GH);
        }

        if (prompt) {
            gc.setFill(Color.rgb(0, 8, 24, 0.90));
            gc.fillRoundRect(x + GuardianEntity.GW / 2 - 85, y - 32, 170, 26, 8, 8);
            gc.setStroke(Color.web("#ffd700")); gc.setLineWidth(1.5);
            gc.strokeRoundRect(x + GuardianEntity.GW / 2 - 85, y - 32, 170, 26, 8, 8);
            gc.setFill(Color.web("#ffd700")); gc.setFont(Font.font("Serif", FontWeight.BOLD, 13));
            gc.setTextAlign(TextAlignment.CENTER); gc.fillText("[ E / ESPAÇO: CONVERSAR ]", x + GuardianEntity.GW / 2, y - 15);
        }
    }

    private void drawPortal(GraphicsContext gc, double px, boolean unlocked, double height, double timeSeconds) {
        double pulse = 0.8 + Math.sin(timeSeconds * 3.0) * 0.2;
        Color pColor = unlocked ? Color.rgb(0, 130, 255, 0.20 * pulse) : Color.rgb(255, 40, 40, 0.20 * pulse);
        gc.setFill(pColor); gc.fillOval(px - 42, height / 2.0 - 66, 100, 100);
        gc.setStroke(unlocked ? Color.web("#40d0ff") : Color.web("#ff4444")); gc.setLineWidth(3.5);
        gc.strokeOval(px - 42, height / 2.0 - 66, 100, 100);
        // Label
        gc.setFont(Font.font("Serif", FontWeight.BOLD, 12));
        gc.setFill(unlocked ? Color.web("#40d0ff") : Color.web("#ff6666"));
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText(unlocked ? "PORTAL\nABERTO" : "PORTAL\nSELADO", px + 8, height / 2.0 - 20);
    }

    /** B3-FIX: projéteis renderizados convertendo coordenadas de mundo para tela. */
    private void drawProjectiles(GraphicsContext gc, GameContext ctx) {
        boolean isP5 = (ctx.getState() == GameContext.State.P5);
        for (Projectile p : ctx.getProjectiles()) {
            // Converte para coordenadas de tela (para P1-P4 com câmera; P5 já está em tela)
            double screenX = (isP5 || p.isArena()) ? p.getX() : ctx.getCamera().toScreenX(p.getX());
            double screenY = p.getY();

            if (p.getType() == Projectile.Type.HERO_BUBBLE) {
                // Bolha bonita com brilho
                gc.setFill(Color.rgb(160, 240, 255, 0.85));
                gc.fillOval(screenX - 8, screenY - 8, 16, 16);
                gc.setStroke(Color.rgb(0, 200, 255, 0.7)); gc.setLineWidth(1.5);
                gc.strokeOval(screenX - 8, screenY - 8, 16, 16);
                gc.setFill(Color.rgb(255, 255, 255, 0.5));
                gc.fillOval(screenX - 5, screenY - 5, 5, 5); // highlight
            } else {
                gc.setFill(Color.web("#ff2a4b"));
                gc.fillOval(screenX - 6, screenY - 6, 12, 12);
                gc.setFill(Color.rgb(255, 80, 80, 0.4));
                gc.fillOval(screenX - 10, screenY - 10, 20, 20); // halo
            }
        }
    }

    private void drawAlert(GraphicsContext gc, GameContext ctx, double width, double height) {
        if (ctx.getAlertMessage().isEmpty()) return;
        long el = ctx.getNanoTime() - ctx.getAlertTime();
        if (el > 3_800_000_000L) return;
        double alpha = Math.min(1.0, (3_800_000_000L - el) / 700_000_000.0);
        gc.setFill(Color.rgb(0, 6, 20, alpha * 0.92));
        gc.fillRoundRect(width / 2.0 - 410, height - 98, 820, 66, 14, 14);
        gc.setStroke(Color.web("#ffd700")); gc.setLineWidth(1.5);
        gc.strokeRoundRect(width / 2.0 - 410, height - 98, 820, 66, 14, 14);
        gc.setFill(Color.rgb(255, 215, 0, alpha));
        gc.setFont(Font.font("Serif", FontWeight.BOLD, 18));
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText(ctx.getAlertMessage(), width / 2.0, height - 60);
    }

    private void drawEnd(GraphicsContext gc, GameContext ctx, double width, double height, boolean win) {
        drawGradientBackground(gc, width, height,
            win ? "#041408" : "#140408", win ? "#0a2d10" : "#2a0810", win ? "#103a1a" : "#400a16");
        ctx.getParticleSystem().render(gc);
        gc.setTextAlign(TextAlignment.CENTER); gc.setTextBaseline(VPos.CENTER);
        gc.setFont(Font.font("Serif", FontWeight.BOLD, 80));
        gc.setFill(win ? Color.web("#ffd700") : Color.web("#ff2828"));
        gc.fillText(win ? "✦ VITÓRIA ✦" : "GAME OVER", width / 2.0, 210);
        gc.setFont(Font.font("Serif", 26));
        gc.setFill(win ? Color.web("#88ffaa") : Color.web("#ff9090"));
        gc.fillText(win ? "Adapa purificou o oceano Apsu!" : "Adapa caiu nas profundezas...", width / 2.0, 320);
        gc.setFont(Font.font("Serif", FontWeight.BOLD, 22));
        gc.setFill(Color.web("#ffd700"));
        gc.fillText("Tabuletas: " + ctx.getTabletsCollected() + " / " + ctx.getTotalTablets(), width / 2.0, 390);
        gc.setFill(Color.web("#80b8d0")); gc.setFont(Font.font("Serif", 16));
        gc.fillText("Herói: " + ctx.getHeroType().getName() + "  |  Dificuldade: " + ctx.getDifficulty().getLabel(), width / 2.0, 430);
        gc.setFill(Color.web("#ffd700")); gc.setFont(Font.font("Serif", FontWeight.BOLD, 22));
        gc.fillText("[ ESPAÇO / R / ENTER — Menu Principal ]", width / 2.0, height - 80);
    }

    private void drawGradientBackground(GraphicsContext gc, double width, double height, String top, String mid, String bot) {
        gc.setFill(new LinearGradient(0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
            new Stop(0, Color.web(top)), new Stop(0.5, Color.web(mid)), new Stop(1, Color.web(bot))));
        gc.fillRect(0, 0, width, height);
    }

    private void drawShadow(GraphicsContext gc, double cx, double cy, double rw, double rh) {
        gc.setFill(Color.rgb(2, 8, 14, 0.40));
        gc.fillOval(cx - rw / 2, cy - rh / 2, rw, rh);
    }
}
