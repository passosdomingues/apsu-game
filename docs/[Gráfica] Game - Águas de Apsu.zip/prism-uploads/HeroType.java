package br.apsu.model.hero;

import javafx.scene.paint.Color;

/**
 * Atributos e características de cada variante de Herói.
 * Overhaul: velocidades e acelerações calibradas para nado fluido e responsivo.
 */
public enum HeroType {
    GUARDIAO("Guardião dos Oceanos",
        "sprites/adapa/01_adapa_heroi.png",
        "sprites/adapa/01_adapa_nadando_disparo_bolhas.png",
        "sprites/adapa/01_adapa_nadando_atirando_bolhas.png",
        "sprites/adapa/01_adapa_heroi",
        16.0, 2.80, 0.955, 0.03, 1.0, "#4db8ff",
        "Equilibrado — Ótimo controle e velocidade responsiva."),

    ABISSAL("Apkallu Abissal",
        "sprites/adapa/01_adapa_var_abissal.png",
        "sprites/adapa/01_adapa_nadando_disparo_bolhas.png",
        "sprites/adapa/01_adapa_nadando_atirando_bolhas.png",
        "sprites/adapa/01_adapa_var_abissal",
        14.0, 2.40, 0.970, 0.01, 1.6, "#1b6fa8",
        "Tanque Pesado — Muita inércia e poder de ataque devastador."),

    DEUS("Deus Dourado",
        "sprites/adapa/01_adapa_var_deus_dourado.png",
        "sprites/adapa/01_adapa_nadando_disparo_bolhas.png",
        "sprites/adapa/01_adapa_nadando_atirando_bolhas.png",
        "sprites/adapa/01_adapa_var_deus_dourado",
        20.0, 3.60, 0.940, 0.05, 1.2, "#ffd700",
        "Velocista — Altíssima velocidade máxima e deslumbrante drift."),

    RECIFE("Guardião dos Recifes",
        "sprites/adapa/01_adapa_var_recife.png",
        "sprites/adapa/01_adapa_nadando_disparo_bolhas.png",
        "sprites/adapa/01_adapa_nadando_atirando_bolhas.png",
        "sprites/adapa/01_adapa_var_recife",
        17.5, 4.00, 0.910, 0.04, 1.0, "#44cc88",
        "Tático Ágil — Desaceleração rápida e curvas ultra precisas.");

    private final String name, staticSpritePath, attack1Path, attack2Path, swimDir;
    private final double maxSpeed, accel, drag, buoy, pwr;
    private final String auraHex, description;

    HeroType(String name, String staticSpritePath, String attack1Path, String attack2Path, String swimDir,
             double maxSpeed, double accel, double drag, double buoy, double pwr, String auraHex, String description) {
        this.name = name;
        this.staticSpritePath = staticSpritePath;
        this.attack1Path = attack1Path;
        this.attack2Path = attack2Path;
        this.swimDir = swimDir;
        this.maxSpeed = maxSpeed;
        this.accel = accel;
        this.drag = drag;
        this.buoy = buoy;
        this.pwr = pwr;
        this.auraHex = auraHex;
        this.description = description;
    }

    public String getName() { return name; }
    public String getStaticSpritePath() { return staticSpritePath; }
    public String getAttack1Path() { return attack1Path; }
    public String getAttack2Path() { return attack2Path; }
    public String getSwimDir() { return swimDir; }
    public double getMaxSpeed() { return maxSpeed; }
    public double getAccel() { return accel; }
    public double getDrag() { return drag; }
    public double getBuoy() { return buoy; }
    public double getPwr() { return pwr; }
    public String getAuraHex() { return auraHex; }
    public Color getAura() { return Color.web(auraHex); }
    public String getDescription() { return description; }
}
