package br.apsu.model;

import br.apsu.model.hero.HeroEntity;
import br.apsu.model.hero.HeroType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes de Unidade — HeroEntity")
public class HeroEntityTest {

    private HeroEntity hero;

    @BeforeEach
    void setUp() {
        hero = new HeroEntity(HeroType.GUARDIAO, 5.0);
    }

    @Test
    @DisplayName("Inicialização correta dos atributos do herói")
    void testHeroInitialization() {
        assertEquals(HeroType.GUARDIAO, hero.getType());
        assertEquals(5.0, hero.getHp());
        assertEquals(5.0, hero.getMaxHP());
        assertEquals(100.0, hero.getX());
        assertTrue(hero.isFacingRight());
        assertFalse(hero.isInvulnerable());
        assertFalse(hero.hasBubblePower());
    }

    @Test
    @DisplayName("Atualização cinemática de nado para a direita")
    void testSwimmingRightMovement() {
        double startX = hero.getX();
        hero.updatePhysics(false, true, false, false, 0, 768, 0);
        assertTrue(hero.getX() > startX, "O herói deve ter se movido para a direita");
        assertTrue(hero.getVx() > 0, "A velocidade horizontal deve ser positiva");
        assertTrue(hero.isFacingRight(), "O herói deve estar virado para a direita");
    }

    @Test
    @DisplayName("Diferenciação de física entre o Velocista (Deus) e o Tanque (Abissal)")
    void testHeroPhysicsDifferentiation() {
        HeroEntity deus = new HeroEntity(HeroType.DEUS, 5.0);
        HeroEntity abissal = new HeroEntity(HeroType.ABISSAL, 5.0);

        deus.updatePhysics(false, true, false, false, 0, 768, 0);
        abissal.updatePhysics(false, true, false, false, 0, 768, 0);

        assertTrue(deus.getVx() > abissal.getVx(), "O Deus Dourado deve acelerar mais rápido que o Apkallu Abissal");
    }

    @Test
    @DisplayName("Aplicação de dano e janela de invulnerabilidade")
    void testDamageAndInvulnerability() {
        hero.applyDamage(1.5, 1000L);
        assertEquals(3.5, hero.getHp(), 0.001);
        assertTrue(hero.isInvulnerable());

        // Dano subsequente durante a invulnerabilidade deve ser ignorado
        hero.applyDamage(1.0, 2000L);
        assertEquals(3.5, hero.getHp(), 0.001);

        // Após expirar a janela (2.2s), invulnerabilidade deve desativar
        hero.checkInvulnerability(3_500_000_000L);
        assertFalse(hero.isInvulnerable());
    }

    @Test
    @DisplayName("Cura de vida respeitando o limite maxHP")
    void testHealing() {
        hero.applyDamage(2.0, 1000L);
        assertEquals(3.0, hero.getHp(), 0.001);

        hero.heal(1.5);
        assertEquals(4.5, hero.getHp(), 0.001);

        hero.heal(2.0);
        assertEquals(5.0, hero.getHp(), 0.001, "A vida não deve ultrapassar maxHP");
    }
}
