package br.apsu.graphics;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.effect.BlendMode;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;

/**
 * Motor de iluminação dinâmica, cáusticas de luz solar e iluminação bioluminescente.
 */
public class LightingEngine {

    public void drawSunCaustics(GraphicsContext gc, double width, double height, double timeSeconds) {
        for (int i = 0; i < 8; i++) {
            double sx = 60 + i * 200 + Math.sin(timeSeconds * 0.3 + i) * 22;
            double wave = Math.sin(timeSeconds * 0.5 + i * 0.7) * 15;
            gc.setFill(Color.rgb(140, 210, 255, 0.04 + Math.sin(timeSeconds * 0.2 + i) * 0.015));
            gc.fillPolygon(new double[]{sx + wave, sx + 60 + wave, sx + 200 + 60, sx + 200}, new double[]{0, 0, height, height}, 4);
        }
    }

    public void drawBioluminescentHalo(GraphicsContext gc, double cx, double cy, double radius, Color glowColor) {
        gc.save();
        gc.setGlobalBlendMode(BlendMode.ADD);
        RadialGradient g = new RadialGradient(
            0, 0, cx, cy, radius, false, CycleMethod.NO_CYCLE,
            new Stop(0, glowColor.deriveColor(0, 1, 1, 0.35)),
            new Stop(1, Color.TRANSPARENT)
        );
        gc.setFill(g);
        gc.fillOval(cx - radius, cy - radius, radius * 2, radius * 2);
        gc.restore();
    }

    public void drawGeyserHeatGlow(GraphicsContext gc, double gx, double gy, double gw, double gh) {
        gc.setFill(Color.rgb(200, 210, 255, 0.18));
        gc.fillRect(gx + 10, gy, gw - 20, gh);
        gc.setFill(Color.rgb(255, 160, 60, 0.30));
        gc.fillOval(gx, gy + gh - 30, gw, 30);
    }
}
