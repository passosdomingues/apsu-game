# 📝 CHANGELOG — As Águas de Apsu

> Formato baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/)
> Versionamento seguindo [Semantic Versioning](https://semver.org/lang/pt-BR/) — `MAJOR.MINOR.PATCH`
>
> - **MAJOR**: mudança que quebra compatibilidade (ex: novo engine, refactor completo)
> - **MINOR**: nova feature ou fase adicionada
> - **PATCH**: bugfix, ajuste de balance, correção visual

---

## [1.3.0] - 2026-11-18 - Suíte 197 Testes, Portal 3D, Boss 3D e Limpeza de Gameplay

### Adicionado
- Restauração do portal 3D dedicado de Atlântida (`15_portal_atlantica_3d.obj`) com rotação de vortex no eixo de profundidade.
- Dimensionamento e ancoragem do lorde abissal Kullullû 3D (360x520) na arena da Fase 5.
- Suíte completa de testes automatizados expandida para 197 testes com 100% de sucesso.

### Modificado
- Filtro `Mesh_0` no script de exportação do navio naufragado (`07_navio_naufragado_elemento-cenario`), eliminando o baú decorativo da carcaça e garantindo que o baú da Fase 2 que desperta as bolhas seja único.
- Redesign de pacing: remoção de estalactites/estalagmites de coral e descarte de inimigos secundários (Delfim Abissal e Lula Vampira) para melhor leitura de tela e gameplay fluido.

---

## [1.2.0] - 2026-11-15 - Arquitetura Zero-Alocação (Sprint Perf R01-R06)

### Adicionado
- `UiFonts`: 24 instâncias estáticas imutáveis de fontes JavaFX eliminando alocações por quadro.
- `Palette`: Gradientes estáticos e cores pré-alocadas para HUD e menus.
- `ParticleSystem`: Pool estático de 320 partículas com compactação swap-and-pop in-place O(1).
- `QuadTree`: Particionamento espacial com retenção estrutural de subárvores e split in-place.
- `AdaptiveRenderController`: Modulação dinâmica de carga visual caso o frametime p95 exceda 33 ms.

### Modificado
- Substituição de `ConcurrentHashMap` por `HashMap` dedicado na JavaFX Application Thread, eliminando overhead de locks sincronizados.
- Ajuste das flags de JVM para G1GC com pausa máxima de 5 ms (`-XX:+UseG1GC -XX:MaxGCPauseMillis=5`).

---

## [1.1.0] - 2026-11-12 - Eliminação de Tremor e Camada 3D em Tempo Real (Sprints 7-8)

### Adicionado
- `Runtime3DLayer`: Renderização de malhas Wavefront OBJ/MTL em JavaFX SubScene transparente sincronizada com a câmera 2D.
- `ObjModelLoader`: Normalização de vértices, coordenadas UV e mapas de textura diffuse.
- Janela de tolerância anti-jitter de 25 ms no X11 para eventos de teclado (`InputManager`).
- Câmera suave com amortecimento crítico exponencial ($\mathrm{blend} = 1 - e^{-10 \Delta t}$).
- Interpolação temporal subpixel lerp no laço de render desacoplado a 60 Hz.

---

## [1.0.0] - 2026-09-01 - Release Inicial Completa

### Adicionado
- 5 fases completas (Águas Claras, Cavernas de Coral, Correntes Abissais, Abismo Vulcânico, Templo de Apsu).
- Trilha sonora adaptativa por profundidade e efeitos sonoros sincronizados.
- Suporte a empacotamento nativo via Maven, Docker e Makefile.

---

## [0.2.0] — 2026-08-07 — Sprints 1, 2 e 3 Concluídas

> **Sprint 1: Core Engine & Menu**  
> **Sprint 2: Game Phases & HUD**  
> **Sprint 3: Build System & DevOps**  
> Implementação completa do jogo em uma única sessão intensiva.
> Compilação validada: `javac` + JDK 21 Temurin + JavaFX `/opt/javafx-21/lib` → **0 erros**.

### Adicionado
- `pom.xml` — Maven + JavaFX 21.0.3 linux, javafx-maven-plugin 0.0.8, assembly fat JAR (APSU-010)
- `src/main/java/ApsuGame.java` — jogo completo monolítico ~600 linhas (APSU-011–028):
  - Input `Set<KeyCode>` + eventos pontuais `onKey()`
  - Menu oceânico animado (bolhas, gradiente, seleção ↑↓)
  - Diálogo Enki 7 linhas + avatar PNG/fallback
  - Câmera `camX` deadzone 35%, herói WASD flip horizontal
  - **Fase 1** — Águas Claras: 4 inimigos senoidal, Tabuleta, portal
  - **Fase 2** — Cavernas Coral: obstulos sólidos, Easter Egg baú, Tabuleta
  - **Fase 3** — Boss Kullullû: HP bar 5 hits, bolhas leque, feixes guiados, Tabuleta
  - HUD: corações, tabuletas 0/3→3/3, fase, dificuldade
  - Partículas: 14/evento (dourado/vermelho/ciano), fade
  - Vitória (orbital dourado) + Game Over (vermelho, restart R)
  - SpriteManager fallback geométrico — zero NPE
- `src/main/resources/` — 6 sprites: hero(1.3MB) boss(565KB) npc(744KB) bg1(978KB) bg2(895KB) bg3(957KB) (APSU-016)
- `Makefile` — build/run/run-local/package/docker-build/docker-run/mpi-demo/clean/help, JAVAFX_PATH configurável (APSU-030/032)
- `Dockerfile` — multi-stage Maven builder + Liberica JDK 21 Full + X11 libs (APSU-031)
- `mpi/MapGenerator.c` — MPI_Scatter/Gather 8 processos, mapa colorido ANSI 3 fases (APSU-033)
- `.gitignore` — Java/Maven/JavaFX/Docker/MPI/IDEs/OS (APSU-017)
- `planning/ARCHITECTURE.md` — ADR-008: FXGL avaliado e rejeitado para v1.0

### Corrigido
- BLOCK-001: `pom.xml` não existia → criado
- BLOCK-002: sprites fora de `src/main/resources/` → copiados

### Notas
- **Build Maven bloqueado:** Maven usa JDK 17 (JAVA_HOME). Fix: `export JAVA_HOME=/opt/java-temurin-21`
- **Build direto OK:** `javac` JDK 21 Temurin + JAVAFX_PATH → 4 .class gerados sem erro
- **FXGL avaliado:** Rejeitado (ADR-008) — migrar seria reescrever o projeto

---

## [0.1.0] — 2026-08-07 — Sprint 0 Concluída

> **Sprint 0: Kickoff & Game Plan**
> Primeira versão registrada. Apenas assets e planejamento — sem código executável ainda.

### Adicionado
- `GamePlan.md` — documento de design completo com mecânicas, fases e requisitos técnicos
- `Apkallu.png` — sprite base do herói Adapa fornecido pelo designer
- Sprites gerados por IA com estilo coerente ao Apkallu:
  - `boss_kullullu_*.png` — Boss: Kullullû corrompido (visual sombrio, tons roxo/preto)
  - `npc_enki_*.png` — NPC: Enki deus das águas (tons dourado/azul, cetro)
  - `bg1_aguas_claras_*.png` — Background Fase 1: águas azuis claras tropicais
  - `bg2_cavernas_coral_*.png` — Background Fase 2: cavernas escuras com corais
  - `bg3_templo_submerso_*.png` — Background Fase 3: templo mesopotâmico submerso
- `implementation_plan.md` — plano técnico de implementação aprovado pelo Tech Lead

### Decisões Técnicas
- Stack definida: JavaFX 21 + Maven 3.9 + Docker (Liberica) + GNU Make + OpenMPI
- Resolução alvo: 1366×768 fullscreen adaptativo
- Dificuldades: Sábio (5❤, inimigos lentos) e Ira de Enki (3❤, inimigos rápidos)
- Colisão: AABB simples (suficiente para side-scroller)
- Sprite fallback: formas geométricas quando PNG não encontrado (resiliência)

---

## [0.0.1] — 2026-07-28 — Projeto Iniciado

### Adicionado
- Repositório criado em `/home/rafael/github/cache/grafica/Game/`
- Reunião inicial de kickoff: tema mesopotâmico aprovado
- Personagem principal definido: Adapa, o Apkallu (homem-peixe sábio)

---

## Convenção de Tipos de Mudança

| Tag | Descrição |
|---|---|
| `Adicionado` | Nova funcionalidade ou arquivo |
| `Modificado` | Mudança em funcionalidade existente |
| `Depreciado` | Funcionalidade que será removida em breve |
| `Removido` | Funcionalidade removida |
| `Corrigido` | Correção de bug |
| `Segurança` | Correção de vulnerabilidade |
| `Balance` | Ajuste em valores de gameplay (HP, velocidade, etc.) |
| `Visual` | Mudança cosmética sem impacto em gameplay |

---

## Template para Nova Entrada

```markdown
## [X.Y.Z] — YYYY-MM-DD — Título da Release

> **Sprint N: Nome da Sprint**
> Breve descrição do que foi entregue.

### Adicionado
- Item adicionado (APSU-XXX)

### Modificado
- Item modificado (APSU-XXX)

### Corrigido
- Bug corrigido — descrição do problema e solução (APSU-XXX)

### Balance
- Velocidade dos inimigos ajustada: 2.2 → 2.5 (Modo Sábio)

### Notas para Próxima Versão
- Lista de débitos técnicos identificados
```
