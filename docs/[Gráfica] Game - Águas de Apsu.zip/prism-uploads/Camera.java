package br.apsu.core;

/**
 * Câmera 2.5D desacoplada para gerenciamento de rolagem de tela.
 */
public class Camera {
    private double x;
    private final double viewportWidth;
    private final double worldWidth;

    public Camera(double viewportWidth, double worldWidth) {
        this.viewportWidth = viewportWidth;
        this.worldWidth = worldWidth;
        this.x = 0;
    }

    public void update(double targetWorldX) {
        double targetCamX = targetWorldX - viewportWidth * 0.3;
        this.x = Math.max(0, Math.min(worldWidth - viewportWidth, targetCamX));
    }

    public double getX() { return x; }
    public void setX(double x) { this.x = x; }
    public double toScreenX(double worldX) { return worldX - x; }
}
